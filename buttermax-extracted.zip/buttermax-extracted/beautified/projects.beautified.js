(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [327], {
        8291: function(e, r, t) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/projects", function() {
                return t(7761)
            }])
        },
        192: function(e, r, t) {
            "use strict";
            var n = t(5893),
                l = t(7294),
                i = t(2797),
                a = t.n(i),
                u = t(6010),
                s = t(6489),
                c = t(7735),
                o = t(9352),
                d = t(2364),
                f = t(3890),
                m = t(8440);
            t(9726);
            let v = e => {
                let {
                    active: r,
                    className: t,
                    fixed: i
                } = e, v = (0, l.useRef)(), p = (0, c.v8)(v, {
                    uniforms: {
                        uActive: {
                            value: 0
                        },
                        tDraw: {
                            value: null
                        },
                        uMapResolution: {
                            value: new Vector2(1)
                        }
                    },
                    keepAlive: !0
                }, !0), h = (0, o.F)(), _ = (0, d.rE)(), {
                    container: g
                } = (0, c.pq)();
                (0, l.useEffect)(() => {
                    p && p.shader.uniforms.tDraw && _ && (p.setStyle(), p.shader.uniforms.tDraw.value = _)
                }, [p, _]), (0, l.useEffect)(() => {
                    if (p && h) {
                        let {
                            secondary: e
                        } = h;
                        p.shader.set("uType", 1), r && p.shader.tween("uBorderColor", new Color(e), RootScene.TR_DURATION, "easeOutCubic")
                    }
                }, [p, h]), (0, l.useEffect)(() => {
                    if (i) return;
                    let e = (0, m.l2)("scrollY", e => {
                        p && (p.scrollPos = e || 0)
                    });
                    return () => e()
                }, [p]);
                let w = (0, l.useCallback)(() => {
                    i && p && (p.element.group.position.y = -(getBusState("scrollY") || 0))
                }, [p]);
                (0, f.y2)(w);
                let {
                    resize: y
                } = (0, m.d_)();
                (0, l.useEffect)(() => {
                    y && p && p.handleResize()
                }, [y, p]);
                let {
                    full: R
                } = (0, s.WZ)();
                return (0, n.jsx)("div", {
                    ref: v,
                    className: (0, u.Z)(a().root, R, t)
                })
            };
            v.displayName = "Background", r.Z = v
        },
        1770: function(e, r, t) {
            "use strict";
            var n = t(5893),
                l = t(7294),
                i = t(6010),
                a = t(4924),
                u = t(545),
                s = t(3890),
                c = t(8440);
            let o = l.forwardRef((e, r) => {
                let {
                    className: t,
                    copyLines: o,
                    moveCharacters: d = !1,
                    enable3D: f = !0,
                    offsets: m = [{
                        x: -.01,
                        z: -2
                    }, {
                        x: .9,
                        z: -1
                    }, {
                        x: -.1,
                        z: -1
                    }, {
                        x: .2,
                        z: 2
                    }]
                } = e, v = (0, l.useRef)([]), [p, h] = (0, u.Rg)(), _ = (0, l.useRef)(new Vector2(0, 0));
                (0, l.useRef)(0), (0, l.useRef)({
                    x: 0,
                    y: 0,
                    value: 0
                }), (0, l.useImperativeHandle)(r, () => ({
                    async animateSet() {
                        p.current.forEach(e => {
                            e.animateSet()
                        })
                    },
                    animateIn() {
                        p.current.forEach(e => {
                            e.animateIn()
                        })
                    },
                    animateOut() {
                        p.current.forEach(e => {
                            e.animateOut()
                        })
                    },
                    setCenterSize(e, r) {
                        _.current.set(e, r)
                    }
                }), []);
                let g = (0, l.useCallback)(() => {
                    (!Device.mobile || Device.mobile.tablet && Stage.width > Stage.height) && y()
                }, []);
                (0, s.Vu)(g);
                let {
                    wait: w
                } = (0, c.mI)(), y = async () => {
                    await w(16), v.current.forEach(async (e, r) => {
                        e.targets = e.querySelectorAll(".words p");
                        let t = e.offsetWidth,
                            n = Stage.width < 1024 ? 45 : Stage.width < 1200 ? 79.5 : Stage.width < 1600 ? 150 : Stage.width < 2e3 ? 200 : Stage.width < 2500 ? 250 : 300,
                            l = 6 + m[r].z,
                            i = (Device.mobile, .5 * t),
                            a = Device.mobile ? .35 * _.current.width : .5 * _.current.width,
                            u = 0;
                        if (m[r].z > 0) {
                            let e = Math.range(m[r].x, -1, 1, -i, i);
                            u = m[r].x < 0 ? e - a : e + a
                        } else u = Math.range(m[r].x, -1, 1, -i, i);
                        e.style.transform = "translateX(".concat(u, "px)"), e.style.fontSize = "".concat((1 - 2 * l * Math.tan(15 * (Math.PI / 180)) / (2 * (l - 1) * Math.tan(15 * (Math.PI / 180)))) * n + n, "px"), e.targets.forEach(async e => {
                            e.style.zIndex = m[r].z
                        })
                    })
                };
                return (0, n.jsx)("div", {
                    className: (0, i.Z)(t),
                    children: o.map((e, r) => {
                        let {
                            words: t,
                            full: l
                        } = e;
                        return (0, n.jsxs)("div", {
                            ref: e => v.current[r] = e,
                            children: [(0, n.jsx)("div", {
                                className: "proxy",
                                children: (0, n.jsx)(a.Z, {
                                    text: l
                                }, r)
                            }), (0, n.jsx)("div", {
                                className: "words",
                                children: t.map((e, r) => (0, n.jsx)(a.Z, {
                                    ref: h,
                                    text: e.word || e,
                                    enable3D: (!Device.mobile || Device.mobile.tablet && Stage.width > Stage.height) && f,
                                    glui: !0
                                }, r))
                            })]
                        }, "line - ".concat(r, " "))
                    })
                })
            });
            o.displayName = "HeaderLines", r.Z = o
        },
        832: function(e, r, t) {
            "use strict";
            var n = t(5893),
                l = t(6038),
                i = t(7294),
                a = t(6010),
                u = t(780),
                s = t.n(u),
                c = t(4924),
                o = t(3890);
            let d = i.forwardRef((e, r) => {
                let {
                    className: t,
                    text: u,
                    glui: d,
                    color: f,
                    overflow: m = !0,
                    speedMultiplier: v = 1
                } = e, p = (0, i.useRef)(), h = (0, i.useRef)(null), _ = (0, i.useRef)(null), [g, w] = (0, i.useState)(), [y, R] = (0, i.useState)(), [b, j] = (0, i.useState)(!1), x = (0, i.useRef)(0), C = (0, i.useRef)(), E = (0, i.useRef)(!0), I = (0, i.useRef)(20), S = (0, i.useRef)(!1), N = (0, i.useRef)(), L = (0, i.useRef)(0);
                (0, i.useImperativeHandle)(r, () => ({
                    async enable() {
                        j(!0)
                    },
                    async disable() {
                        j(!1)
                    },
                    setColor(e) {
                        g && y && (g.shader.set("uColor2", e), y.shader.set("uColor2", e))
                    },
                    onResize: T,
                    resize() {
                        h.current.resize(), _.current.resize()
                    },
                    isReady: () => Z.current
                }), [g, y]);
                let Z = (0, i.useRef)(Promise.create()),
                    k = (0, i.useCallback)(async () => {
                        await Z.current, g && y && !E.current && (x.current -= I.current * Render.HZ_MULTIPLIER, C.current && (x.current %= C.current + 0 || 0), g.element.x = x.current, y.element.x = x.current)
                    }, [g, y]);
                (0, o.y2)(k);
                let T = (0, i.useCallback)(async () => {
                    if (!Z.current || !g || !y) return;
                    await Z.current, C.current = g.$.offsetWidth;
                    let {
                        left: e,
                        width: r,
                        right: t
                    } = p.current.getBoundingClientRect();
                    g.wrapper.show(), g.gluiElements.forEach(e => {
                        e.alpha = 1
                    }), y.wrapper.show(), y.gluiElements.forEach(e => {
                        e.alpha = 1
                    }), m && (g.shader.set("uDPR", RenderManager.DPR), y.shader.set("uDPR", RenderManager.DPR), g.shader.set("uOverflow", 1), y.shader.set("uOverflow", 1), g.shader.set("uBounds", new Vector2(e, e + r)), y.shader.set("uBounds", new Vector2(e, e + r))), E.current && (g.wrapper.hide(), g.gluiElements.forEach(e => {
                        e.alpha = 0
                    }), y.wrapper.hide(), y.gluiElements.forEach(e => {
                        e.alpha = 0
                    })), I.current = Device.mobile ? 1.3 : 2, I.current *= v
                }, [g, y]);
                return (0, i.useEffect)(() => {
                    g && y && (async () => {
                        await Promise.all([g.isReady(), y.isReady()]), Z.current.resolve(), g.afterResize = T
                    })()
                }, [g, y]), (0, i.useEffect)(() => {
                    let e = async () => {
                        S.current || (await Z.current, E.current = !1, S.current = !0, N.current && N.current.kill(), N.current = l.ZP.to(L, {
                            current: 1,
                            ease: "Cubic.easeOut",
                            duration: .45,
                            onStart: () => {
                                var e, r;
                                null == g || null === (e = g.wrapper) || void 0 === e || e.show(), null == y || null === (r = y.wrapper) || void 0 === r || r.show()
                            },
                            onUpdate: () => {
                                var e, r;
                                null == g || null === (e = g.gluiElements) || void 0 === e || e.forEach(e => e.alpha = L.current), null == y || null === (r = y.gluiElements) || void 0 === r || r.forEach(e => e.alpha = L.current)
                            }
                        }))
                    }, r = async () => {
                        S.current && (await Z.current, E.current = !0, S.current = !1, N.current && N.current.kill(), N.current = l.ZP.to(L, {
                            current: 0,
                            ease: "Cubic.easeOut",
                            duration: .45,
                            onComplete: () => {
                                var e, r;
                                null == g || null === (e = g.wrapper) || void 0 === e || e.hide(), null == y || null === (r = y.wrapper) || void 0 === r || r.hide()
                            },
                            onUpdate: () => {
                                g.gluiElements.forEach(e => e.alpha = L.current), y.gluiElements.forEach(e => e.alpha = L.current)
                            }
                        }))
                    };
                    b ? (T(), e()) : r()
                }, [b, g, y, T]), (0, n.jsx)("div", {
                    className: (0, a.Z)(t, s().marquee),
                    ref: r,
                    children: (0, n.jsxs)("div", {
                        className: s()["marquee--inner"],
                        ref: p,
                        children: [(0, n.jsx)(c.Z, {
                            ref: h,
                            text: u,
                            glui: !0,
                            overflow: !0,
                            onReady: w,
                            type: 1,
                            style: {
                                color: f
                            },
                            manuallyHide: !0,
                            revert: !1
                        }), (0, n.jsx)(c.Z, {
                            ref: _,
                            text: "".concat(u, " ").concat(u),
                            glui: !0,
                            overflow: !0,
                            onReady: R,
                            type: 1,
                            style: {
                                color: f
                            },
                            manuallyHide: !0,
                            revert: !1
                        })]
                    })
                })
            });
            d.displayName = "Marquee", r.Z = d
        },
        7121: function(e, r, t) {
            "use strict";
            var n = t(5893),
                l = t(7294),
                i = t(7671),
                a = t(7735),
                u = t(3890),
                s = t(1163),
                c = t(8440);
            let o = l.forwardRef((e, r) => {
                let t, {
                        children: o,
                        data: d
                    } = e,
                    {
                        container: f,
                        container3d: m
                    } = (0, a.pq)(),
                    {
                        query: v,
                        pathname: p
                    } = (0, s.useRouter)(),
                    [h, _] = (0, l.useState)(),
                    g = (0, l.useRef)(),
                    w = (0, l.useRef)(!0),
                    y = (0, l.useRef)(),
                    {
                        wait: R
                    } = (0, c.mI)();
                (0, l.useEffect)(() => {
                    if (!h) return;
                    let e = async () => {
                        h.stop(), await R(RootScene.TR_DURATION), h.start()
                    };
                    e()
                }, [h, p]);
                let b = (0, l.useCallback)(e => {
                    if (!g.current || (w.current && (_(g.current), w.current = !1), g.current.raf(e), (0, u.TN)("transitioning"))) return;
                    let r = g.current.scroll;
                    (0, u.ic)("scrollY", r || 0), m && (null == GLUIBaseBridge ? void 0 : GLUIBaseBridge.get3dMultiplier) && (m.group.position.y = GLUIBaseBridge.get3dMultiplier(r)), f && (f.group.position.y = r)
                }, [f, m]);
                (0, u.y2)(b, "RenderManager_before_render");
                let j = (0, l.useCallback)(() => {
                    g.current && g.current.resize()
                }, []);
                return (0, u.Vu)(j), (0, l.useEffect)(() => {
                    let e = "default",
                        r = "black";
                    if (p && ("/" === p || "/contact" === p ? e = "black" : p.includes("/projects/") ? (e = "detail", r = "detail") : "/projects" === p || "/profile" === p ? (e = "detail", r = "brand") : "/workshop" === p ? (e = "workshop", r = "brand") : (e = "custom404", r = "custom404")), (null == d ? void 0 : d.colors) && (null == v ? void 0 : v.slug)) {
                        let r = (0, u.TN)("themes", "theme");
                        r[v.slug] && r[v.slug].colors === d.colors || (0, u.ic)("themes", {
                            ...r,
                            [v.slug]: {
                                ...r[e],
                                ...d.colors
                            }
                        }, "theme"), (0, u.ic)("active", v.slug, "theme")
                    } else(0, u.ic)("active", e, "theme");
                    R(1300).then(() => {
                        var e, t, n, l;
                        (0, u.ic)("headerTheme", r, "theme"), (0, u.ic)("icon", (null == d ? void 0 : d.icon) ? d.icon : "earth", "theme"), p.includes("/projects/") ? (0, u.ic)("clientIcon", null === (e = null == d ? void 0 : null === (t = d.info) || void 0 === t ? void 0 : t.clients[0]) || void 0 === e ? void 0 : null === (n = e.client) || void 0 === n ? void 0 : null === (l = n.value) || void 0 === l ? void 0 : l.image.url, "theme") : (0, u.ic)("clientIcon", !1, "theme")
                    })
                }, [d, v.slug, p]), (0, n.jsx)("div", {
                    className: "page-container",
                    ref: y,
                    children: (0, n.jsx)(i.pi, {
                        autoRaf: !1,
                        ref: g,
                        options: (t = {
                            smoothTouch: !0,
                            touchMultiplier: 1
                        }, Device.mobile && (t = {
                            syncTouch: !1,
                            lerp: .05,
                            smoothTouch: !0,
                            touchMultiplier: 1.5
                        }), t),
                        children: o
                    })
                })
            });
            o.displayName = "PageController", r.Z = o
        },
        7761: function(e, r, t) {
            "use strict";
            t.r(r), t.d(r, {
                __N_SSG: function() {
                    return P
                },
                default: function() {
                    return B
                }
            });
            var n = t(5893),
                l = t(1163),
                i = t(7294),
                a = t(7247),
                u = t.n(a),
                s = t(8440),
                c = t(7735),
                o = t(9726),
                d = t(8477),
                f = t(192),
                m = t(1770),
                v = t(43),
                p = t.n(v),
                h = t(7117),
                _ = t(3890),
                g = t(6038),
                w = t(3302),
                y = t.n(w),
                R = t(2364),
                b = t(4924),
                j = t(2071),
                x = t(832),
                C = t(1664),
                E = t.n(C);
            let I = (0, i.forwardRef)((e, r) => {
                var t, l, a, u, s;
                let {
                    title: c,
                    label: d,
                    slug: f,
                    isLast: m,
                    data: v
                } = e, p = (0, i.useRef)(), w = (0, i.useRef)(null), C = (0, i.useRef)(null), I = (0, i.useRef)(null), S = (0, i.useRef)(null), N = (0, i.useRef)(null), L = (0, i.useRef)(null), Z = (0, R.rE)(), k = (0, i.useRef)(0), [T, D] = (0, i.useState)(), M = (0, i.useRef)(), P = (0, i.useRef)(), B = (0, i.useRef)(), O = (0, i.useRef)(), F = (0, i.useRef)(), z = (0, i.useRef)(), {
                    setSize: A
                } = (0, R.g3)();
                (0, i.useImperativeHandle)(r, () => ({
                    el: () => w.current,
                    getTitle: () => c,
                    async animateSet() {
                        g.ZP.set(w.current, {
                            display: "block"
                        }), g.ZP.set(w.current, {
                            opacity: 0
                        })
                    },
                    animateIn() {
                        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
                        g.ZP.to(w.current, {
                            opacity: 1,
                            duration: 2,
                            ease: "Quart.easeInOut",
                            delay: e
                        })
                    },
                    animateOut() {
                        g.ZP.to(w.current, {
                            opacity: 0,
                            duration: .8,
                            ease: "Quart.easeInOut",
                            onComplete: () => {
                                g.ZP.set(w.current, {
                                    display: "none"
                                })
                            }
                        })
                    },
                    setActive(e, r) {
                        U(e ? "over" : "out", !0)
                    }
                })), (0, i.useEffect)(() => {
                    M.current = new Color("#FFD600"), P.current = new Color("#101010"), B.current = new Color("#101010"), O.current = new Color("#101010" === v.colors.primary ? v.colors.tertiary : v.colors.primary), F.current = new Color("#FFD600"), z.current = new Color(v.colors.secondary)
                }, []);
                let {
                    wait: H
                } = (0, _.mI)();
                (0, i.useEffect)(() => {
                    let e = async () => {
                        await H(() => {
                            var e;
                            return (null == N ? void 0 : null === (e = N.current) || void 0 === e ? void 0 : e.glui()) !== null
                        }), N.current.glui().shader.set("uColor2", z.current), p.current.setColor(z.current);
                        let e = "#101010" === v.colors.primary ? v.colors.tertiary : v.colors.primary;
                        if (D(new Color(e)), S.current) {
                            var r, t, n, l, i, a;
                            await H(() => void 0 !== S.current.glui()), S.current.glui().shader.uniforms.tMap.value = Utils3D.getTexture(null === (r = v.clients[0]) || void 0 === r ? void 0 : null === (t = r.client) || void 0 === t ? void 0 : null === (n = t.value) || void 0 === n ? void 0 : n.image.url), S.current.glui().shader.uniforms.tDraw.value = Z, S.current.glui().shader.set("uColor", new Color(StyleGuide.colors.brand)), S.current.glui().shader.set("uColor2", z.current), S.current.glui().setType(2), await H(RootScene.TR_DURATION), S.current && S.current.glui && (S.current.glui().shader.uniforms.tMap.value = Utils3D.getTexture(null === (l = v.clients[0]) || void 0 === l ? void 0 : null === (i = l.client) || void 0 === i ? void 0 : null === (a = i.value) || void 0 === a ? void 0 : a.image.url))
                        }
                    };
                    e()
                }, [H]);
                let U = (0, i.useCallback)((e, r) => {
                        (!Device.mobile || r) && ("over" === e ? (p.current.enable(), A && !Device.mobile && A(3, !0)) : (p.current.disable(), A && !Device.mobile && A(0, !1)), (Device.mobile || !(window.innerWidth >= 768)) && (tween.current && tween.current.kill(), tween.current = g.ZP.fromTo(k, {
                            current: "out" == e ? 1 : 0
                        }, {
                            current: "out" == e ? 0 : 1,
                            duration: Device.mobile ? .95 : .55,
                            ease: "Cubic.easeOut",
                            onUpdate: () => {
                                var r, t, n;
                                M.current.lerp("out" === e ? F.current : z.current, k.current), P.current.lerp("out" === e ? B.current : O.current, k.current), (null === (r = N.current) || void 0 === r ? void 0 : r.glui()) && (null === (t = S.current) || void 0 === t ? void 0 : t.glui()) && (N.current.glui().shader.set("uColor", M.current), S.current.glui().shader.set("uColor", M.current)), (null === (n = C.current) || void 0 === n ? void 0 : n.glui()) && C.current.glui().current.element.shader.set("uColor", P.current)
                            }
                        })))
                    }, [A]),
                    q = (0, i.useMemo)(() => ({
                        shaderName: "GLUIDetailMediaShader",
                        uniforms: {
                            uParallax: {
                                value: 0
                            },
                            uScale: {
                                value: 0
                            },
                            uVelocity: {
                                value: 0
                            },
                            uMouseMove: {
                                value: new Vector2
                            }
                        }
                    }), []),
                    G = (0, i.useCallback)(() => {
                        C.current.resize(), S.current.resize(), L.current.resize(), p.current.resize(), N.current.resize()
                    }, []);
                return (0, i.useEffect)(() => {
                    let e = async () => {
                        Z && H && (await H(() => void 0 !== L.current.glui()), L.current.glui().shader.uniforms.tDraw.value = Z, H(3e3).then(() => {
                            G(), H(1e3).then(() => {
                                G()
                            })
                        }))
                    };
                    e()
                }, [Z, H]), (0, n.jsx)(E(), {
                    href: "projects/".concat(f),
                    className: y().item,
                    ref: w,
                    onMouseEnter: () => U("over"),
                    onMouseLeave: () => U("out"),
                    children: (0, n.jsx)(o.Zs, {
                        className: y()["item--intrinsic"],
                        ref: I,
                        children: (0, n.jsxs)("div", {
                            className: y()["item--inner"],
                            children: [(0, n.jsx)(x.Z, {
                                className: y()["item--marquee"],
                                text: c,
                                glui: !0,
                                color: Device.mobile ? v.colors.secondary : "#101010",
                                ref: p
                            }), (0, n.jsx)("div", {
                                className: y()["item--label"],
                                children: (0, n.jsx)(b.Z, {
                                    text: "".concat(v.featuredTitle || c, " <span class=").concat(y()["item--label__anno"], ">(").concat(v.year, ")</span>"),
                                    glui: !Utils.query("noglui"),
                                    ref: N
                                })
                            }), (0, n.jsx)(h.Z, {
                                className: y()["item--background"],
                                glui: !0,
                                ref: C,
                                inverseColor: T
                            }), (0, n.jsx)(j.Z, {
                                src: null === (t = null === (l = v.featuredImg) || void 0 === l ? void 0 : l.sizes.i600px) || void 0 === t ? void 0 : t.url,
                                zIndex: 999,
                                className: y()["item--devicewrapper"],
                                ref: L,
                                glui: q
                            }), (0, n.jsx)(j.Z, {
                                className: y()["item--client-icon"],
                                src: (null === (a = v.clients[0]) || void 0 === a ? void 0 : null === (u = a.client) || void 0 === u ? void 0 : null === (s = u.value) || void 0 === s ? void 0 : s.image.url) || "",
                                glui: {
                                    uniforms: {
                                        uColor2: {
                                            value: new Color(10 / 255)
                                        }
                                    }
                                },
                                ref: S
                            })]
                        })
                    })
                })
            });
            I.displayName = "FilteredListItem";
            var S = t(7671);
            let N = (0, i.forwardRef)((e, r) => {
                var t;
                let {
                    className: a,
                    items: u
                } = e, c = (0, S.LZ)(), d = (0, i.useRef)(null), f = (0, i.useRef)(null), m = (0, i.useRef)([]), v = (0, i.useRef)(), g = (0, i.useRef)(-1), w = (0, l.useRouter)(), y = null === (t = w.asPath.split("#")) || void 0 === t ? void 0 : t[1], [R, b] = (0, i.useState)(y && "all" !== y ? u.filter(e => {
                    var r;
                    let {
                        data: t
                    } = e;
                    return null === (r = t.typeOfProject) || void 0 === r ? void 0 : r.find(e => {
                        var r;
                        return e.projectType.value.type === (null === (r = w.asPath.split("#")) || void 0 === r ? void 0 : r[1])
                    })
                }) : u), j = (0, i.useRef)([]), x = (0, i.useRef)(!1), {
                    wait: C
                } = (0, s.mI)();
                (0, i.useImperativeHandle)(r, () => ({
                    async animateSet() {}
                }));
                let E = (0, i.useCallback)(() => {
                    let e = u.filter(e => {
                        var r;
                        let {
                            data: t
                        } = e;
                        return null === (r = t.typeOfProject) || void 0 === r ? void 0 : r.find(e => e.projectType.value.type === x.current)
                    });
                    "all" !== x.current && x.current || (e = u), b(e)
                }, []);
                (0, i.useEffect)(() => {
                    var e;
                    let r = (null === (e = w.asPath.split("#")) || void 0 === e ? void 0 : e[1]) || "all";
                    if (x.current || (x.current = r), r !== x.current) {
                        x.current = r;
                        let e = async () => {
                            let e = await f.current.gluiElement();
                            c.scrollTo(0, {
                                onComplete: async () => {
                                    e.element.shader.tween("uTransition", 1, 400, "easeOutCubic").onComplete(async () => {
                                        var r;
                                        E(), null === (r = e.handleResize) || void 0 === r || r.call(e), await C(100), e.element.shader.tween("uTransition", 0, 450, "easeOutCubic")
                                    })
                                }
                            })
                        };
                        e()
                    }
                }, [w.asPath]), (0, i.useEffect)(() => {
                    let e = async () => {
                        let e = await f.current.gluiElement();
                        e.element.shader.set("uTransition", 0)
                    };
                    e()
                }, []);
                let N = (0, i.useMemo)(() => ({
                        shaderName: "GLUITransitionShader",
                        uniforms: {
                            uTransition: {
                                value: 0
                            }
                        }
                    }), []),
                    L = (0, i.useCallback)(() => {
                        var e;
                        if (getBusState("transitioning")) return;
                        let r = getBusState("scrollY") || 0;
                        if (!Device.mobile.phone || 0 === r) return;
                        let t = r;
                        if (t += .5 * window.innerHeight, (null === (e = m.current[0]) || void 0 === e ? void 0 : e.innerHeight) && m.current[0].innerHeight !== window.innerHeight) return Z();
                        j.current.forEach((e, r) => {
                            if (!m.current[r]) return;
                            let n = Math.abs(t - (m.current[r].y + m.current[r].height / 2));
                            r !== g.current && (!v.current || n < v.current) && (-1 !== g.current && j.current[g.current].setActive(!1, g.current), e.setActive(!0, r), g.current = r), g.current === r && (v.current = n)
                        })
                    }, []);
                (0, _.y2)(L);
                let Z = (0, i.useCallback)(() => {
                    Device.mobile.phone && (m.current[0] || (m.current[0] = {}, m.current[0].innerHeight = window.innerHeight), j.current.forEach((e, r) => {
                        if (!e) return;
                        let {
                            y: t,
                            height: n
                        } = e.el().getBoundingClientRect();
                        m.current[r] || (m.current[r] = {}), m.current[r].y = t + (getBusState("scrollY") || 0), m.current[r].height = n
                    }))
                }, []);
                (0, _.Vu)(Z);
                let k = (0, i.useCallback)(() => R.map((e, r) => {
                    let {
                        title: t,
                        label: l,
                        slug: i,
                        data: a
                    } = e;
                    return (0, n.jsx)(I, {
                        data: a,
                        title: t,
                        label: l,
                        slug: i,
                        ref: e => j.current[r] = e,
                        isLast: r === u.length - 1
                    }, a.id + y)
                }), [R]);
                return (0, n.jsxs)("div", {
                    className: "".concat(a, " ").concat(p().filteredList),
                    ref: d,
                    children: [(0, n.jsx)(o.Zs, {
                        children: (0, n.jsx)(h.Z, {
                            className: p()["filteredList--bg"],
                            glui: N,
                            ref: f
                        })
                    }), k()]
                })
            });
            N.displayName = "FilteredList";
            var L = t(5887),
                Z = t.n(L);
            let k = (0, i.forwardRef)((e, r) => {
                let {
                    className: t,
                    filters: a
                } = e, u = (0, i.useRef)(null), c = (0, i.useRef)(null), o = (0, i.useRef)([]), d = (0, i.useRef)([]), f = (0, l.useRouter)(), m = (0, i.useRef)(!1), v = (0, i.useRef)(0);
                (0, i.useRef)(!1);
                let {
                    flag: p,
                    wait: _
                } = (0, s.xb)(), w = (0, i.useRef)(0), y = (0, i.useRef)(!1), R = (0, i.useRef)(0);
                (0, i.useImperativeHandle)(r, () => ({
                    async animateSet() {
                        await _("ready"), g.ZP.set(c.current, {
                            opacity: 0
                        })
                    },
                    async animateIn() {
                        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
                        await _("ready"), g.ZP.to(c.current, {
                            opacity: 1,
                            duration: 2,
                            ease: "Quart.easeInOut",
                            delay: e
                        })
                    }
                }));
                let j = (0, i.useCallback)((e, r) => {
                    f.push("/projects".concat(m.current === e ? "" : "#".concat(e)), void 0, {
                        shallow: !0
                    }), d.current.forEach(async (t, n) => {
                        let l = await t.gluiElement();
                        m._index = r, l.element.scale = m.current === e ? 0 : n == r ? 1 : 0
                    })
                }, []);
                (0, i.useEffect)(() => {
                    R.current = u.current.scrollWidth;
                    let e = window.addEventListener("mousemove", x, {
                            passive: !0
                        }),
                        r = window.addEventListener("mouseup", E, {
                            passive: !0
                        });
                    return () => {
                        window.removeEventListener("mousemove", e), window.removeEventListener("mouseup", r)
                    }
                }, []), (0, i.useEffect)(() => {
                    let e = f.asPath.split("#")[1];
                    m.current = e;
                    let r = a.map(e => e).indexOf(e); - 1 === r && (r = 0), o.current.forEach(async (e, t) => {
                        r !== t ? e.el().classList.remove(Z().active) : e.el().classList.add(Z().active), r === t && (await d.current[r].gluiElement()).element.tween({
                            scaleX: 1
                        }, 350, "easeOutCubic")
                    })
                }, [f.asPath, a]);
                let x = e => {
                        y.current && C(e)
                    },
                    C = (0, i.useCallback)(e => {
                        w.current - e.clientX > 150 || R.current === c.current.offsetWidth || (0 === w.current && (w.current = e.clientX), v.current -= w.current - e.clientX, c.current.style.transform = "translateX(".concat(Math.clamp(v.current, c.current.clientWidth - R.current, 0), "px)"), w.current = e.clientX)
                    }, []),
                    E = (0, i.useCallback)(e => {
                        y.current = !1
                    }, []);
                (0, i.useEffect)(() => {
                    0 !== o.current.length && p("ready", o.current)
                }, [o, p]), (0, i.useEffect)(() => {
                    d.current.forEach(async e => {
                        (await e.gluiElement()).element.scaleX = 0
                    })
                }, []);
                let I = (0, i.useCallback)(async e => {
                        (await d.current[e].gluiElement()).element.tween({
                            scaleX: 1
                        }, 750, "easeOutCubic")
                    }, []),
                    S = (0, i.useCallback)(async e => {
                        m._index !== e && (await d.current[e].gluiElement()).element.tween({
                            scaleX: 0
                        }, 350, "easeOutCubic")
                    }, []);
                return (0, n.jsx)("div", {
                    className: "".concat(t || "", " ").concat(Z().filters, " "),
                    ref: u,
                    children: (0, n.jsx)("div", {
                        onMouseDown: () => {
                            y.current = !0
                        },
                        className: Z()["filters--inner"],
                        ref: c,
                        children: a.map((e, r) => (0, n.jsx)("div", {
                            children: (0, n.jsxs)("div", {
                                className: Z()["filters--container"],
                                children: [(0, n.jsx)(b.Z, {
                                    className: Z()["filters--filter"],
                                    text: e,
                                    ref: e => o.current[r] = e,
                                    glui: !0
                                }), (0, n.jsx)(h.Z, {
                                    ref: e => d.current[r] = e,
                                    className: Z().underline,
                                    inverseColor: "#101010",
                                    glui: {
                                        uActive: !0
                                    }
                                }), (0, n.jsx)("div", {
                                    onClick: () => j(e, r),
                                    onMouseEnter: () => I(r),
                                    onMouseLeave: () => S(r),
                                    className: Z()["filters--hitarea"]
                                })]
                            })
                        }, r))
                    })
                })
            });
            k.displayName = "FilterBar";
            var T = t(7121);
            let D = {
                    heading: {
                        lines: [{
                            words: ["ALL"],
                            full: "ALL",
                            dir: 1
                        }, {
                            words: ["WORKS"],
                            full: "WORKS",
                            dir: 1
                        }]
                    }
                },
                M = (e, r) => {
                    var t;
                    let {
                        data: a
                    } = e, [v, p] = (0, i.useState)(), h = (0, i.useRef)(), _ = (0, i.useRef)(!0), g = (0, i.useRef)(), w = (0, i.useRef)(), y = (0, i.useRef)(), R = (0, l.useRouter)(), b = (0, i.useRef)(null), j = (0, i.useRef)(null), x = (0, i.useRef)(null), C = (0, i.useRef)(null), E = (0, i.useRef)(), I = (0, s.uZ)(BaseScene, {
                        clearColor: "#101010"
                    }), {
                        wait: S
                    } = (0, s.xb)();
                    (0, i.useImperativeHandle)(r, () => (0, d.Z)({
                        $element: b,
                        scene: I
                    }), []), (0, i.useEffect)(() => {
                        if (setBusState("arrowAction", () => {
                                R.push("/projects")
                            }), !x.current) return;
                        let e = async () => {
                            C.current.animateSet(), x.current.animateSet(), await S(2e3), x.current.animateIn()
                        };
                        e()
                    }, []);
                    let L = [];
                    a.projects.filter(e => {
                        let {
                            typeOfProject: r
                        } = e;
                        return r
                    }).forEach(e => {
                        let {
                            typeOfProject: r
                        } = e;
                        r.forEach(e => L.push(e.projectType.value.type))
                    }), (t = L).unshift("all"), L = t.filter((e, r) => t.indexOf(e) === r);
                    let Z = (0, i.useCallback)(e => {
                        if (!h.current) return;
                        _.current && (p(h.current), _.current = !1), h.current.raf(e);
                        let r = h.current.scroll;
                        setBusState("scrollY", r || 0), g.current.glui() && (g.current.glui().wrapper.group.position.y = r), w.current.glui() && (w.current.glui().wrapper.group.position.y = r), y.current.elGlui() && (y.current.elGlui().wrapper.group.position.y = r), j.current.glui() && (j.current.glui().wrapper.group.position.y = r)
                    }, []);
                    return (0, s.y2)(Z, "RenderManager_before_render"), (0, n.jsx)(c.YR, {
                        scene: I,
                        children: (0, n.jsx)(T.Z, {
                            ref: E,
                            children: (0, n.jsxs)("div", {
                                className: "page ".concat(u().projects),
                                ref: b,
                                children: [(0, n.jsx)(f.Z, {
                                    active: "/projects" === R.pathname,
                                    fixed: !0
                                }), (0, n.jsx)(o.Zs, {
                                    children: (0, n.jsxs)("div", {
                                        className: u().projects__header,
                                        children: [(0, n.jsx)(m.Z, {
                                            className: u()["projects__header--lines"],
                                            copyLines: D.heading.lines,
                                            enable3D: !1
                                        }), (0, n.jsx)(k, {
                                            filters: L,
                                            ref: x
                                        })]
                                    })
                                }), (0, n.jsx)("div", {
                                    className: u().projects__team,
                                    children: (0, n.jsx)(N, {
                                        items: a.projects.map(e => {
                                            let {
                                                title: r,
                                                maps: t,
                                                info: n,
                                                slug: l,
                                                ...i
                                            } = e;
                                            return {
                                                maps: t,
                                                title: r,
                                                label: n.clients.map(e => {
                                                    var r;
                                                    let {
                                                        client: t
                                                    } = e;
                                                    return null == t ? void 0 : null === (r = t.value) || void 0 === r ? void 0 : r.name
                                                }).join(", ") || "",
                                                slug: l,
                                                data: {
                                                    ...i,
                                                    ...n
                                                }
                                            }
                                        }),
                                        className: u()["projects__team--members"],
                                        ref: C
                                    })
                                })]
                            })
                        })
                    })
                };
            M.displayName = "Projects";
            var P = !0,
                B = (0, i.forwardRef)(M)
        },
        8477: function(e, r, t) {
            "use strict";
            var n = t(6038);
            r.Z = e => () => ({
                entryTransition: async r => {
                    var t, l, i;
                    let {
                        rootScene: a,
                        delay: u = 0,
                        first: s
                    } = r;
                    n.p8.set(e.$element.current, {
                        opacity: 0
                    }), null === (t = e.animateSet) || void 0 === t || t.call(e, s);
                    let c = null == e ? void 0 : null === (l = e.scene) || void 0 === l ? void 0 : l.current;
                    if (c && a) {
                        let e = await c;
                        Global.scene = e, a.setTo(e.rt), a.navigate(s)
                    }
                    return null === (i = e.animateIn) || void 0 === i || i.call(e, s), n.p8.to(e.$element.current, {
                        opacity: 1,
                        duration: 1.15,
                        ease: "Cubic.easeInOut",
                        delay: u,
                        onComplete: () => {
                            var r;
                            null === (r = e.onAnimateInComplete) || void 0 === r || r.call(e, s)
                        }
                    })
                },
                exitTransition: r => {
                    var t;
                    let {
                        to: l,
                        delay: i
                    } = r;
                    return null === (t = e.animateOut) || void 0 === t || t.call(e), n.p8.to(e.$element.current, {
                        opacity: 0,
                        duration: 1.15,
                        ease: "Cubic.easeInOut",
                        delay: i
                    })
                }
            })
        },
        2797: function(e) {
            e.exports = {
                root: "Background_root__AbScr"
            }
        },
        5887: function(e) {
            e.exports = {
                filters: "FilterBar_filters__Ziv5m",
                "filters--inner": "FilterBar_filters--inner__worsG",
                underline: "FilterBar_underline__wV7JY",
                "filters--container": "FilterBar_filters--container__JQExu",
                "filters--hitarea": "FilterBar_filters--hitarea__a1gW5",
                "filters--filter": "FilterBar_filters--filter__CPlvB",
                active: "FilterBar_active__kwk2B"
            }
        },
        43: function(e) {
            e.exports = {
                filteredList: "FilteredList_filteredList__N2uTo",
                "filteredList--bg": "FilteredList_filteredList--bg__CT045"
            }
        },
        3302: function(e) {
            e.exports = {
                item: "FilteredListItem_item__mY9Ky",
                "item--intrinsic": "FilteredListItem_item--intrinsic__xaES3",
                "item--inner": "FilteredListItem_item--inner__UoCbM",
                "item--border": "FilteredListItem_item--border__NSDHk",
                "item--background": "FilteredListItem_item--background__rHrxD",
                "item--img": "FilteredListItem_item--img__ctGQk",
                "item--marquee": "FilteredListItem_item--marquee__aIGeA",
                "item--devicewrapper": "FilteredListItem_item--devicewrapper__fBMTb",
                "item--device": "FilteredListItem_item--device__R33aN",
                "item--label": "FilteredListItem_item--label__VsM6_",
                "item--label__anno": "FilteredListItem_item--label__anno__nRLbJ",
                "item--label__hover": "FilteredListItem_item--label__hover__CW4Y1",
                "item--client-icon": "FilteredListItem_item--client-icon__4upIS"
            }
        },
        780: function(e) {
            e.exports = {
                marquee: "Marquee_marquee__T1CA2",
                "marquee--inner": "Marquee_marquee--inner__sM18S"
            }
        },
        7247: function(e) {
            e.exports = {
                projects: "projects_projects__Tl4_e",
                "projects--transitionBG": "projects_projects--transitionBG__Vs6R_",
                projects__header: "projects_projects__header__Tr9ej",
                "projects__header--lines": "projects_projects__header--lines__UiZCi",
                projects__team: "projects_projects__team__A59Ze",
                "projects__team--header": "projects_projects__team--header__m1tv3",
                projects__footer: "projects_projects__footer__jUSIq",
                "projects__footer--cta": "projects_projects__footer--cta__ObJ2K"
            }
        }
    },
    function(e) {
        e.O(0, [671, 774, 888, 179], function() {
            return e(e.s = 8291)
        }), _N_E = e.O()
    }
]);