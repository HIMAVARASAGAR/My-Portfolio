(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [335], {
        7803: function(e, t, r) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/contact", function() {
                return r(1025)
            }])
        },
        192: function(e, t, r) {
            "use strict";
            var a = r(5893),
                n = r(7294),
                l = r(2797),
                s = r.n(l),
                u = r(6010),
                o = r(6489),
                i = r(7735),
                c = r(9352),
                d = r(2364),
                m = r(3890),
                _ = r(8440);
            r(9726);
            let p = e => {
                let {
                    active: t,
                    className: r,
                    fixed: l
                } = e, p = (0, n.useRef)(), f = (0, i.v8)(p, {
                    uniforms: {
                        uActive: {
                            value: 0
                        },
                        tDraw: {
                            value: null
                        },
                        uMapResolution: {
                            value: new Vector2(1)
                        }
                    },
                    keepAlive: !0
                }, !0), h = (0, c.F)(), y = (0, d.rE)(), {
                    container: v
                } = (0, i.pq)();
                (0, n.useEffect)(() => {
                    f && f.shader.uniforms.tDraw && y && (f.setStyle(), f.shader.uniforms.tDraw.value = y)
                }, [f, y]), (0, n.useEffect)(() => {
                    if (f && h) {
                        let {
                            secondary: e
                        } = h;
                        f.shader.set("uType", 1), t && f.shader.tween("uBorderColor", new Color(e), RootScene.TR_DURATION, "easeOutCubic")
                    }
                }, [f, h]), (0, n.useEffect)(() => {
                    if (l) return;
                    let e = (0, _.l2)("scrollY", e => {
                        f && (f.scrollPos = e || 0)
                    });
                    return () => e()
                }, [f]);
                let g = (0, n.useCallback)(() => {
                    l && f && (f.element.group.position.y = -(getBusState("scrollY") || 0))
                }, [f]);
                (0, m.y2)(g);
                let {
                    resize: b
                } = (0, _.d_)();
                (0, n.useEffect)(() => {
                    b && f && f.handleResize()
                }, [b, f]);
                let {
                    full: w
                } = (0, o.WZ)();
                return (0, a.jsx)("div", {
                    ref: p,
                    className: (0, u.Z)(s().root, w, r)
                })
            };
            p.displayName = "Background", t.Z = p
        },
        7121: function(e, t, r) {
            "use strict";
            var a = r(5893),
                n = r(7294),
                l = r(7671),
                s = r(7735),
                u = r(3890),
                o = r(1163),
                i = r(8440);
            let c = n.forwardRef((e, t) => {
                let r, {
                        children: c,
                        data: d
                    } = e,
                    {
                        container: m,
                        container3d: _
                    } = (0, s.pq)(),
                    {
                        query: p,
                        pathname: f
                    } = (0, o.useRouter)(),
                    [h, y] = (0, n.useState)(),
                    v = (0, n.useRef)(),
                    g = (0, n.useRef)(!0),
                    b = (0, n.useRef)(),
                    {
                        wait: w
                    } = (0, i.mI)();
                (0, n.useEffect)(() => {
                    if (!h) return;
                    let e = async () => {
                        h.stop(), await w(RootScene.TR_DURATION), h.start()
                    };
                    e()
                }, [h, f]);
                let E = (0, n.useCallback)(e => {
                    if (!v.current || (g.current && (y(v.current), g.current = !1), v.current.raf(e), (0, u.TN)("transitioning"))) return;
                    let t = v.current.scroll;
                    (0, u.ic)("scrollY", t || 0), _ && (null == GLUIBaseBridge ? void 0 : GLUIBaseBridge.get3dMultiplier) && (_.group.position.y = GLUIBaseBridge.get3dMultiplier(t)), m && (m.group.position.y = t)
                }, [m, _]);
                (0, u.y2)(E, "RenderManager_before_render");
                let x = (0, n.useCallback)(() => {
                    v.current && v.current.resize()
                }, []);
                return (0, u.Vu)(x), (0, n.useEffect)(() => {
                    let e = "default",
                        t = "black";
                    if (f && ("/" === f || "/contact" === f ? e = "black" : f.includes("/projects/") ? (e = "detail", t = "detail") : "/projects" === f || "/profile" === f ? (e = "detail", t = "brand") : "/workshop" === f ? (e = "workshop", t = "brand") : (e = "custom404", t = "custom404")), (null == d ? void 0 : d.colors) && (null == p ? void 0 : p.slug)) {
                        let t = (0, u.TN)("themes", "theme");
                        t[p.slug] && t[p.slug].colors === d.colors || (0, u.ic)("themes", {
                            ...t,
                            [p.slug]: {
                                ...t[e],
                                ...d.colors
                            }
                        }, "theme"), (0, u.ic)("active", p.slug, "theme")
                    } else(0, u.ic)("active", e, "theme");
                    w(1300).then(() => {
                        var e, r, a, n;
                        (0, u.ic)("headerTheme", t, "theme"), (0, u.ic)("icon", (null == d ? void 0 : d.icon) ? d.icon : "earth", "theme"), f.includes("/projects/") ? (0, u.ic)("clientIcon", null === (e = null == d ? void 0 : null === (r = d.info) || void 0 === r ? void 0 : r.clients[0]) || void 0 === e ? void 0 : null === (a = e.client) || void 0 === a ? void 0 : null === (n = a.value) || void 0 === n ? void 0 : n.image.url, "theme") : (0, u.ic)("clientIcon", !1, "theme")
                    })
                }, [d, p.slug, f]), (0, a.jsx)("div", {
                    className: "page-container",
                    ref: b,
                    children: (0, a.jsx)(l.pi, {
                        autoRaf: !1,
                        ref: v,
                        options: (r = {
                            smoothTouch: !0,
                            touchMultiplier: 1
                        }, Device.mobile && (r = {
                            syncTouch: !1,
                            lerp: .05,
                            smoothTouch: !0,
                            touchMultiplier: 1.5
                        }), r),
                        children: c
                    })
                })
            });
            c.displayName = "PageController", t.Z = c
        },
        1025: function(e, t, r) {
            "use strict";
            r.r(t), r.d(t, {
                __N_SSG: function() {
                    return U
                },
                default: function() {
                    return G
                }
            });
            var a = r(5893),
                n = r(1163),
                l = r(7294),
                s = r(8477),
                u = r(3196),
                o = r.n(u),
                i = r(5658),
                c = r(4924),
                d = r(6010),
                m = r(7117),
                _ = r(7305),
                p = r.n(_);
            let f = l.forwardRef((e, t) => {
                let {
                    className: r = "",
                    revealed: n
                } = e;
                (0, l.useRef)(null);
                let s = (0, l.useRef)(null),
                    u = (0, l.useRef)(null),
                    o = (0, l.useRef)(null),
                    [i, _] = (0, l.useState)(""),
                    f = (0, l.useRef)({
                        action: "https://activetheory.us16.list-manage.com/subscribe/post?u=51f3fe8dc612ed64d8f2b11ec&amp;id=bb0a374a94&amp;f_id=003b02e0f0",
                        method: "post"
                    });
                (0, l.useImperativeHandle)(t, () => ({
                    el: () => u.current,
                    animateSet: () => {
                        $(s.current).css({
                            opacity: 0
                        })
                    },
                    animateIn: async () => {
                        await o.current.isReady();
                        let e = await o.current.gluiEl();
                        e.element.hide(), $(s.current).css({
                            opacity: 1
                        })
                    },
                    animateOut: async () => {
                        await o.current.isReady();
                        let e = await o.current.gluiEl();
                        e.element.show(), $(s.current).css({
                            opacity: 0
                        })
                    }
                }), []);
                let [h, y] = (0, l.useState)(!1), [v, g] = (0, l.useState)(!1), b = (0, l.useCallback)(e => {
                    e.preventDefault(), h && (u.current.action = f.current.action, u.current.method = f.current.method, u.current.submit())
                }, [h]), w = (0, l.useCallback)(e => {
                    let t = s.current.value;
                    if (g(t.length > 0), !t.match(/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)) return y(!1);
                    y(!0)
                }, []);
                return (0, l.useEffect)(() => {
                    let e = async () => {
                        await o.current.isReady();
                        let e = await o.current.gluiEl();
                        e.afterResize = () => {
                            n && e.element.hide()
                        }
                    };
                    e(), "ios" === Device.system.os && s.current.classList.add(p()["ios-fix"])
                }, [n]), (0, a.jsx)("div", {
                    className: (0, d.Z)(r, p()["newsletter-signup"]),
                    children: (0, a.jsxs)("form", {
                        name: "mc-embedded-subscribe-form",
                        className: p()["newsletter-signup--form"],
                        action: "https://activetheory.us16.list-manage.com/subscribe/post?u=51f3fe8dc612ed64d8f2b11ec&id=bb0a374a94&f_id=003b02e0f0",
                        method: "post",
                        target: "_blank",
                        onSubmit: b,
                        ref: u,
                        children: [(0, a.jsxs)("div", {
                            id: "mc_embed_signup_scroll",
                            children: [(0, a.jsx)(c.Z, {
                                ref: o,
                                className: p()["newsletter-signup-fakecopy"],
                                text: "SIGN UP TO OUR NEWSLETTER",
                                type: "h2",
                                glui: !0
                            }), (0, a.jsx)("input", {
                                type: "email",
                                name: "EMAIL",
                                id: "mce-EMAIL-glui",
                                placeholder: "SIGN UP TO OUR NEWSLETTER",
                                ref: s,
                                onChange: w,
                                style: {
                                    color: !h && v ? "#00FF00" : "#FFD600"
                                }
                            }), (0, a.jsx)("div", {
                                hidden: "",
                                children: (0, a.jsx)("input", {
                                    type: "hidden",
                                    name: "tags",
                                    readOnly: !0,
                                    value: "3544104"
                                })
                            }), (0, a.jsx)("div", {
                                "aria-hidden": "true",
                                style: {
                                    position: "absolute",
                                    left: "-5000px"
                                },
                                children: (0, a.jsx)("input", {
                                    type: "text",
                                    name: "b_51f3fe8dc612ed64d8f2b11ec_bb0a374a94",
                                    tabIndex: "-1",
                                    readOnly: !0,
                                    value: ""
                                })
                            }), (0, a.jsxs)("div", {
                                id: "mce-responses",
                                children: [(0, a.jsx)("div", {
                                    id: "mce-error-response",
                                    style: {
                                        display: "none"
                                    }
                                }), (0, a.jsx)("div", {
                                    id: "mce-success-response",
                                    style: {
                                        display: "none"
                                    }
                                })]
                            })]
                        }), (0, a.jsx)("div", {
                            "aria-label": "button",
                            className: p()["newsletter-signup-arrow"],
                            style: {
                                maskImage: "url('images/arrowUp.png')",
                                display: h ? "block" : "none"
                            },
                            onClick: b
                        }), (0, a.jsx)("input", {
                            type: "submit",
                            name: "subscribe",
                            id: "mc-embedded-subscribe",
                            className: p()["newsletter-signup--submit"],
                            readOnly: !0,
                            value: "Subscribe"
                        }), (0, a.jsx)(m.Z, {
                            className: p()["newsletter-signup-border"],
                            onClick: b,
                            inverse: !0,
                            glui: !0
                        })]
                    })
                })
            });
            f.displayName = "NewsLetterSignup";
            var h = r(8440),
                y = r(4884),
                v = r.n(y);
            let g = (0, l.forwardRef)((e, t) => {
                let {
                    successMessage: r,
                    errorMessage: n
                } = e, s = (0, l.useRef)(null), u = (0, l.useRef)(null), [o, i] = (0, l.useState)(!1), {
                    wait: d
                } = (0, h.xb)();
                return (0, l.useEffect)(() => {
                    let e = async () => {
                        await d(1e4), s.current.hide(), u.current.hide(), i(!1)
                    };
                    o && e()
                }, [o]), (0, l.useImperativeHandle)(t, () => ({
                    showSuccess: async () => {
                        s.current.show(), u.current.hide(), i(!0)
                    },
                    showError: () => {
                        u.current.show(), s.current.hide(), i(!0)
                    },
                    hideElements: async () => {
                        s.current.hide(), u.current.hide()
                    }
                }), []), (0, a.jsxs)("div", {
                    className: v()["notice-wrapper"],
                    children: [(0, a.jsx)(c.Z, {
                        ref: s,
                        className: v()["notice--success"],
                        text: r,
                        type: "p",
                        glui: !0
                    }), (0, a.jsx)(c.Z, {
                        ref: u,
                        className: v()["notice--error"],
                        text: n,
                        type: "p",
                        glui: !0
                    })]
                })
            });
            g.displayName = "EnquiryFormNotice";
            var b = r(9162),
                w = r.n(b),
                E = r(2071),
                x = r(1928),
                R = r.n(x);
            let N = e => {
                let {
                    text: t,
                    enabled: r,
                    onClick: n
                } = e;
                (0, l.useRef)(null);
                let s = (0, l.useRef)(null),
                    u = (0, l.useRef)(null),
                    o = (0, l.useRef)(null),
                    i = (0, l.useRef)(null),
                    _ = {
                        primary: new Color("#FFD600"),
                        secondary: new Color("#101010"),
                        disabledBorder: new Color("#1b1b1b0a")
                    };
                (0, l.useEffect)(() => {
                    let e = async () => {
                        let e = await s.current.gluiElement();
                        e.element.shader.tween("uBorderAlpha", r ? 1 : .2, 450, "easeOutCubic")
                    };
                    e(), o.current.style.cursor = r ? "pointer" : "not-allowed"
                }, [r]);
                let p = async () => {
                    let e = async () => {
                        let e = await s.current.gluiElement();
                        e.element.shader.set("uType", 4), e.element.shader.set("uTransition", 0)
                    }, t = async () => {
                        let e = await u.current.gluiEl();
                        e.shader.tween("uColor", _.secondary, 300, "easeOutCubic"), e.shader.tween("uColor2", _.primary, 300, "easeOutCubic")
                    }, r = async () => {
                        let e = await i.current.gluiEl();
                        await i.current.setDraw(), e.shader.tween("uColor", _.secondary, 450, "easeOutCubic"), e.shader.tween("uColor2", _.primary, 450, "easeOutCubic")
                    };
                    e(), t(), r()
                };
                (0, l.useEffect)(() => {
                    p()
                }, []);
                let f = async () => {
                    if (!r) return;
                    let e = await s.current.gluiElement(),
                        t = await u.current.gluiEl(),
                        a = await i.current.gluiEl();
                    e.element.shader.tween("uTransition", 1, 300, "easeOutCubic"), t.shader.tween("uColor", _.primary, 300, "easeOutCubic"), t.shader.tween("uColor2", _.secondary, 300, "easeOutCubic"), a.shader.tween("uColor", _.primary, 450, "easeOutCubic"), a.shader.tween("uColor2", _.secondary, 450, "easeOutCubic")
                }, h = async () => {
                    if (!r) return;
                    let e = await s.current.gluiElement(),
                        t = await u.current.gluiEl(),
                        a = await i.current.gluiEl();
                    e.element.shader.tween("uTransition", 0, 300, "easeOutCubic"), t.shader.tween("uColor", _.secondary, 300, "easeOutCubic"), t.shader.tween("uColor2", _.primary, 300, "easeOutCubic"), a.shader.tween("uColor", _.secondary, 450, "easeOutCubic"), a.shader.tween("uColor2", _.primary, 450, "easeOutCubic")
                }, y = async e => {
                    n && n(e), p()
                };
                return (0, a.jsxs)("div", {
                    ref: o,
                    className: (0, d.Z)(R().glb, r ? R()["glb--bordered"] : ""),
                    onClick: y,
                    onTouchStart: y,
                    onMouseEnter: f,
                    onMouseLeave: h,
                    children: [(0, a.jsx)(m.Z, {
                        ref: s,
                        className: R()["glb-bg--bordered"],
                        glui: {
                            uniforms: {
                                uType: 4
                            }
                        }
                    }), (0, a.jsx)(c.Z, {
                        ref: u,
                        className: R()["glb-text"],
                        text: t,
                        glui: !0
                    }), (0, a.jsx)(E.Z, {
                        ref: i,
                        className: R()["glb-arrow"],
                        zIndex: 200,
                        src: "images/arrowUp.png",
                        width: "18",
                        height: "18",
                        icon: "arrowUp",
                        glui: {
                            textureParams: {
                                forceNewTexture: !0
                            },
                            keepAlive: !0,
                            uniforms: {
                                uType: {
                                    value: 2
                                }
                            },
                            uColor: {
                                value: null
                            },
                            uColor2: {
                                value: null
                            }
                        }
                    })]
                })
            };
            N.displayName = "GLUIButton";
            var C = r(545);
            let j = l.forwardRef((e, t) => {
                let {
                    className: r = ""
                } = e, [n] = (0, C.z$)(), s = (0, l.useRef)(null), u = (0, l.useRef)(null), o = (0, l.useRef)(null), i = (0, l.useRef)(null), _ = (0, l.useRef)(null), p = (0, l.useRef)(null), y = (0, l.useRef)(null), v = (0, l.useRef)(null), b = (0, l.useRef)([]), [E, x] = (0, l.useState)(!1), R = [u, o, p, y], j = (0, l.useRef)(null), [S, O] = (0, l.useState)({
                    name: "",
                    lastname: "",
                    message: "",
                    company: ""
                }), [I, k] = (0, l.useState)(!1), {
                    wait: q
                } = (0, h.mI)();
                (0, l.useImperativeHandle)(t, () => ({
                    animateSet: () => {
                        var e, t;
                        _.current.hideElements(), R.forEach(e => {
                            var t, r;
                            let a = (null === (t = e.current) || void 0 === t ? void 0 : null === (r = t.el) || void 0 === r ? void 0 : r.call(t)) || e.current;
                            a && $(a).css({
                                opacity: 0
                            })
                        }), b.current.forEach(async e => {
                            await e.isReady();
                            let t = await e.gluiEl();
                            t.afterResize = () => {
                                E && e.hide()
                            }, t.element.show()
                        }), null === (t = (e = v.current).animateSet) || void 0 === t || t.call(e, E)
                    },
                    animateIn: async () => {
                        var e, t;
                        await q(3700), b.current.forEach(e => {
                            e.glui().element.hide()
                        }), R.forEach(e => {
                            var t, r;
                            let a = (null === (t = e.current) || void 0 === t ? void 0 : null === (r = t.el) || void 0 === r ? void 0 : r.call(t)) || e.current;
                            a && $(a).css({
                                opacity: 1
                            })
                        }), x(!0), null === (t = (e = v.current).animateIn) || void 0 === t || t.call(e)
                    },
                    animateOut: () => {
                        var e, t;
                        R.forEach(e => {
                            var t, r;
                            let a = (null === (t = e.current) || void 0 === t ? void 0 : null === (r = t.el) || void 0 === r ? void 0 : r.call(t)) || e.current;
                            a && $(a).css({
                                opacity: 0
                            })
                        }), b.current.forEach(async e => {
                            await e.isReady();
                            let t = await e.gluiEl();
                            t.element.show()
                        }), null === (t = (e = v.current).animateOut) || void 0 === t || t.call(e)
                    }
                }), []);
                let Z = (0, l.useCallback)(async e => {
                        if (e.preventDefault(), !I) return;
                        let t = Hydra.LOCAL ? "" : "https://email-nt4pqv3flq-uc.a.run.app",
                            r = t ? fetch(t, {
                                method: "POST",
                                headers: {
                                    "Content-Type": "application/json"
                                },
                                body: JSON.stringify(S)
                            }) : Promise.resolve(JSON.stringify({
                                success: !0
                            }));
                        try {
                            var a;
                            let e = await r,
                                l = await (null == e ? void 0 : null === (a = e.json) || void 0 === a ? void 0 : a.call(e)) || JSON.parse(e);
                            t || console.log("Email sending has been mocked - lacks endpoint: ", S, l), l.success ? (j.current.reset(), k(!1), _.current.showSuccess(), O({
                                name: "",
                                email: "",
                                message: "",
                                company: ""
                            }), Hydra.LOCAL || n("enquiry_form_submit_success")) : (_.current.showError(), console.error("Error sending email", l), Hydra.LOCAL || n("enquiry_form_submit_error"))
                        } catch (e) {
                            _.current.showError(), console.error("Error sending email", e), Hydra.LOCAL || n("enquiry_form_submit_error")
                        }
                    }, [S]),
                    T = (0, l.useCallback)(e => String(e).toLowerCase().match(/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|.(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)),
                    M = (0, l.useCallback)(async e => {
                        let t = u.current.value,
                            r = o.current.value,
                            a = y.current.value,
                            n = p.current.value,
                            l = T(r),
                            s = await i.current.gluiElement();
                        !l && r.length > 0 ? s.element.shader.set("uColor", new Color("#ff0000")) : s.element.shader.set("uColor", new Color(1052688)), O({
                            name: t,
                            email: r,
                            message: a,
                            company: n
                        }), k(t.length > 0 && l && a.length > 0)
                    }, [S, O, I]);
                return (0, l.useEffect)(() => {
                    b.current.forEach(async e => {
                        await e.isReady();
                        let t = await e.gluiEl();
                        t.afterResize = () => {
                            E && e.hide()
                        }
                    }), "ios" === Device.system.os && [u, o, p, y].forEach(async e => {
                        e.current && e.current.classList.add(w()["ios-fix"])
                    })
                }, [E]), (0, a.jsxs)("div", {
                    ref: s,
                    className: (0, d.Z)(r, w()["enquiry-form"]),
                    children: [(0, a.jsxs)("form", {
                        className: w()["enquiry-form__form"],
                        name: "enquiry-form",
                        target: "_blank",
                        onSubmit: Z,
                        ref: j,
                        children: [(0, a.jsxs)("div", {
                            className: (0, d.Z)(w().input, w()["input--name"]),
                            children: [(0, a.jsx)(c.Z, {
                                ref: e => b.current[0] = e,
                                className: w()["enquiry-form__fake-label"],
                                text: "NAME *",
                                type: "h2",
                                glui: !0
                            }), (0, a.jsx)("input", {
                                type: "text",
                                name: "NAME",
                                placeholder: "NAME *",
                                onChange: M,
                                ref: u
                            }), (0, a.jsx)(m.Z, {
                                className: w()["input-border"],
                                glui: !0,
                                inverse: !0
                            })]
                        }), (0, a.jsxs)("div", {
                            className: (0, d.Z)(w().input, w()["input--email"]),
                            children: [(0, a.jsx)(c.Z, {
                                ref: e => b.current[1] = e,
                                className: w()["enquiry-form__fake-label"],
                                text: "EMAIL *",
                                type: "h2",
                                glui: !0
                            }), (0, a.jsx)("input", {
                                type: "email",
                                name: "EMAIL",
                                placeholder: "EMAIL *",
                                onChange: M,
                                ref: o
                            }), (0, a.jsx)(m.Z, {
                                ref: i,
                                className: w()["input-border"],
                                glui: !0,
                                inverse: !0
                            })]
                        }), (0, a.jsxs)("div", {
                            className: (0, d.Z)(w().input, w()["input--company"]),
                            children: [(0, a.jsx)(c.Z, {
                                ref: e => b.current[2] = e,
                                className: w()["enquiry-form__fake-label"],
                                text: "COMPANY",
                                type: "h2",
                                glui: !0
                            }), (0, a.jsx)("input", {
                                type: "text",
                                name: "COMPANY",
                                placeholder: "COMPANY",
                                onChange: M,
                                ref: p
                            }), (0, a.jsx)(m.Z, {
                                className: w()["input-border"],
                                glui: !0,
                                inverse: !0
                            })]
                        }), (0, a.jsxs)("div", {
                            className: (0, d.Z)(w().input, w()["input--message"]),
                            children: [(0, a.jsx)(c.Z, {
                                ref: e => b.current[3] = e,
                                className: w()["enquiry-form__fake-label"],
                                text: "WHAT'S UP? *",
                                type: "h2",
                                glui: !0
                            }), (0, a.jsx)("input", {
                                type: "text",
                                name: "MESSAGE",
                                placeholder: "WHAT'S UP? *",
                                onChange: M,
                                ref: y
                            }), (0, a.jsx)(m.Z, {
                                className: w()["input-border"],
                                glui: !0,
                                inverse: !0
                            })]
                        })]
                    }), (0, a.jsxs)("div", {
                        className: w()["enquiry-form__footer"],
                        children: [(0, a.jsx)(g, {
                            ref: _,
                            successMessage: "THANKS FOR REACHING OUT! WE WILL GET BACK TO YOU SOON.",
                            errorMessage: "SOMETHING WENT WRONG, MAYBE PING US HERE HELLO@BUTTERMAX.NET"
                        }), (0, a.jsx)("div", {
                            className: w()["enquiry-form__btns"],
                            children: (0, a.jsx)(N, {
                                text: "SAY HI",
                                enabled: I,
                                onClick: Z
                            })
                        }), (0, a.jsx)(f, {
                            revealed: E,
                            ref: v
                        })]
                    })]
                })
            });
            j.displayName = "EnquiryForm";
            var S = r(7735),
                O = r(7121),
                I = r(192),
                k = r(2364),
                q = r(9726),
                Z = r(2182),
                T = r(3029),
                M = r.n(T);
            let D = (0, l.forwardRef)((e, t) => {
                let {
                    asset: r,
                    className: n
                } = e, s = (0, k.rE)(), u = (0, l.useMemo)(() => ({
                    shaderName: "GLUIMarqueeMSDF",
                    uniforms: {
                        tMSDF: {
                            value: Utils3D.getRepeatTexture("images/contact/title_msdf.png")
                        },
                        uRotation: {
                            value: Stage.width < 1200 ? 0 : Math.PI / 2
                        },
                        uHorizontal: {
                            value: Stage.width < 1200 ? 1 : 0
                        },
                        tDraw: {
                            value: null
                        }
                    }
                }), []);
                return (0, l.useEffect)(() => {
                    s && (u.uniforms.tDraw.value = s)
                }, [s]), (0, a.jsx)("div", {
                    className: (0, d.Z)(n, M().wrapper),
                    children: (0, a.jsx)(E.Z, {
                        className: M().img,
                        glui: u,
                        zIndex: 1
                    })
                })
            });
            D.displayName = "MarqueeMSDF";
            var L = r(6038),
                A = r(375),
                P = r.n(A),
                B = r(3890);
            let F = l.forwardRef((e, t) => {
                let {
                    className: r,
                    text: n,
                    glui: s,
                    color: u,
                    overflow: o = !0,
                    speedMultiplier: i = 1
                } = e, m = (0, l.useRef)(), [_, p] = (0, l.useState)(), [f, h] = (0, l.useState)(), [y, v] = (0, l.useState)(), [g, b] = (0, l.useState)(), [w, E] = (0, l.useState)(), [x, R] = (0, l.useState)(), [N, C] = (0, l.useState)(!1), j = (0, l.useRef)(0), S = (0, l.useRef)(), O = (0, l.useRef)(!0), I = (0, l.useRef)(20), k = (0, l.useRef)(!1), q = (0, l.useRef)(), Z = (0, l.useRef)(0);
                (0, l.useImperativeHandle)(t, () => ({
                    async enable() {
                        C(!0)
                    },
                    async disable() {
                        C(!1)
                    },
                    setColor(e) {
                        _ && f && y && (_.shader.set("uColor2", e), f.shader.set("uColor2", e), y.shader.set("uColor2", e), g.shader.set("uColor2", e), w.shader.set("uColor2", e), x.shader.set("uColor2", e))
                    },
                    onResize: D,
                    isReady: () => T.current
                }), [_, f, y, g, w, x]);
                let T = (0, l.useRef)(Promise.create()),
                    M = (0, l.useCallback)(async () => {
                        await T.current, _ && f && y && g && w && x && !O.current && (j.current -= I.current * Render.HZ_MULTIPLIER, S.current && (j.current %= S.current + 0 || 0), _.element.x = j.current, f.element.x = j.current, y.element.x = j.current, g.element.x = j.current, w.element.x = j.current, x.element.x = j.current)
                    }, [_, f, y, g, w, x]);
                (0, B.y2)(M);
                let D = (0, l.useCallback)(async () => {
                    if (!T.current || !_ || !f || !y || !g || !w || !x) return;
                    await T.current, S.current = _.$.offsetWidth;
                    let {
                        left: e,
                        width: t,
                        right: r
                    } = m.current.getBoundingClientRect();
                    _.wrapper.show(), _.gluiElements.forEach(e => {
                        e.alpha = 1
                    }), f.wrapper.show(), f.gluiElements.forEach(e => {
                        e.alpha = 1
                    }), y.wrapper.show(), y.gluiElements.forEach(e => {
                        e.alpha = 1
                    }), g.wrapper.show(), g.gluiElements.forEach(e => {
                        e.alpha = 1
                    }), w.wrapper.show(), w.gluiElements.forEach(e => {
                        e.alpha = 1
                    }), x.wrapper.show(), x.gluiElements.forEach(e => {
                        e.alpha = 1
                    }), o && (_.shader.set("uDPR", RenderManager.DPR), f.shader.set("uDPR", RenderManager.DPR), y.shader.set("uDPR", RenderManager.DPR), g.shader.set("uDPR", RenderManager.DPR), w.shader.set("uDPR", RenderManager.DPR), x.shader.set("uDPR", RenderManager.DPR), _.shader.set("uOverflow", 1), f.shader.set("uOverflow", 1), y.shader.set("uOverflow", 1), g.shader.set("uOverflow", 1), w.shader.set("uOverflow", 1), x.shader.set("uOverflow", 1), _.shader.set("uBounds", new Vector2(e, e + t)), f.shader.set("uBounds", new Vector2(e, e + t)), y.shader.set("uBounds", new Vector2(e, e + t)), g.shader.set("uBounds", new Vector2(e, e + t)), w.shader.set("uBounds", new Vector2(e, e + t)), x.shader.set("uBounds", new Vector2(e, e + t))), O.current && (_.wrapper.hide(), _.gluiElements.forEach(e => {
                        e.alpha = 0
                    }), f.wrapper.hide(), f.gluiElements.forEach(e => {
                        e.alpha = 0
                    }), y.wrapper.hide(), y.gluiElements.forEach(e => {
                        e.alpha = 0
                    }), g.wrapper.hide(), g.gluiElements.forEach(e => {
                        e.alpha = 0
                    }), w.wrapper.hide(), w.gluiElements.forEach(e => {
                        e.alpha = 0
                    }), x.wrapper.hide(), x.gluiElements.forEach(e => {
                        e.alpha = 0
                    })), I.current = Device.mobile ? 1.3 : 2, I.current *= i
                }, [_, f, y, g, w, x]);
                return (0, l.useEffect)(() => {
                    _ && f && y && g && w && x && (async () => {
                        await Promise.all([_.isReady(), f.isReady(), y.isReady(), g.isReady(), w.isReady(), x.isReady()]), T.current.resolve(), _.afterResize = D
                    })()
                }, [_, f, y, g, w, x]), (0, l.useEffect)(() => {
                    let e = async () => {
                        k.current || (await T.current, O.current = !1, k.current = !0, q.current && q.current.kill(), q.current = L.ZP.to(Z, {
                            current: 1,
                            ease: "Cubic.easeOut",
                            duration: .45,
                            onStart: () => {
                                var e, t, r, a, n, l;
                                null == _ || null === (e = _.wrapper) || void 0 === e || e.show(), null == f || null === (t = f.wrapper) || void 0 === t || t.show(), null == y || null === (r = y.wrapper) || void 0 === r || r.show(), null == g || null === (a = g.wrapper) || void 0 === a || a.show(), null == w || null === (n = w.wrapper) || void 0 === n || n.show(), null == x || null === (l = x.wrapper) || void 0 === l || l.show()
                            },
                            onUpdate: () => {
                                var e, t, r, a, n, l;
                                null == _ || null === (e = _.gluiElements) || void 0 === e || e.forEach(e => e.alpha = Z.current), null == f || null === (t = f.gluiElements) || void 0 === t || t.forEach(e => e.alpha = Z.current), null == y || null === (r = y.gluiElements) || void 0 === r || r.forEach(e => e.alpha = Z.current), null == g || null === (a = g.gluiElements) || void 0 === a || a.forEach(e => e.alpha = Z.current), null == w || null === (n = w.gluiElements) || void 0 === n || n.forEach(e => e.alpha = Z.current), null == x || null === (l = x.gluiElements) || void 0 === l || l.forEach(e => e.alpha = Z.current)
                            }
                        }))
                    }, t = async () => {
                        k.current && (await T.current, O.current = !0, k.current = !1, q.current && q.current.kill(), q.current = L.ZP.to(Z, {
                            current: 0,
                            ease: "Cubic.easeOut",
                            duration: .45,
                            onComplete: () => {
                                var e, t, r, a, n, l;
                                null == _ || null === (e = _.wrapper) || void 0 === e || e.hide(), null == f || null === (t = f.wrapper) || void 0 === t || t.hide(), null == y || null === (r = y.wrapper) || void 0 === r || r.hide(), null == g || null === (a = g.wrapper) || void 0 === a || a.hide(), null == w || null === (n = w.wrapper) || void 0 === n || n.hide(), null == x || null === (l = x.wrapper) || void 0 === l || l.hide()
                            },
                            onUpdate: () => {
                                _.gluiElements.forEach(e => e.alpha = Z.current), f.gluiElements.forEach(e => e.alpha = Z.current), y.gluiElements.forEach(e => e.alpha = Z.current), g.gluiElements.forEach(e => e.alpha = Z.current), w.gluiElements.forEach(e => e.alpha = Z.current), x.gluiElements.forEach(e => e.alpha = Z.current)
                            }
                        }))
                    };
                    N ? (D(), e()) : t()
                }, [N, _, f, y, g, w, x, D]), (0, a.jsx)("div", {
                    className: (0, d.Z)(r, P().marquee),
                    ref: t,
                    children: (0, a.jsxs)("div", {
                        className: P()["marquee--inner"],
                        ref: m,
                        children: [(0, a.jsx)(c.Z, {
                            text: n,
                            glui: !0,
                            overflow: !0,
                            onReady: p,
                            type: 1,
                            style: {
                                color: u
                            },
                            manuallyHide: !0,
                            revert: !1
                        }), (0, a.jsx)(c.Z, {
                            text: n,
                            glui: !0,
                            overflow: !0,
                            onReady: h,
                            type: 1,
                            style: {
                                color: u
                            },
                            manuallyHide: !0,
                            revert: !1
                        }), (0, a.jsx)(c.Z, {
                            text: n,
                            glui: !0,
                            overflow: !0,
                            onReady: v,
                            type: 1,
                            style: {
                                color: u
                            },
                            manuallyHide: !0,
                            revert: !1
                        }), (0, a.jsx)(c.Z, {
                            text: n,
                            glui: !0,
                            overflow: !0,
                            onReady: b,
                            type: 1,
                            style: {
                                color: u
                            },
                            manuallyHide: !0,
                            revert: !1
                        }), (0, a.jsx)(c.Z, {
                            text: n,
                            glui: !0,
                            overflow: !0,
                            onReady: E,
                            type: 1,
                            style: {
                                color: u
                            },
                            manuallyHide: !0,
                            revert: !1
                        }), (0, a.jsx)(c.Z, {
                            text: n,
                            glui: !0,
                            overflow: !0,
                            onReady: R,
                            type: 1,
                            style: {
                                color: u
                            },
                            manuallyHide: !0,
                            revert: !1
                        })]
                    })
                })
            });
            F.displayName = "MarqueeContact";
            let H = (e, t) => {
                let {
                    data: r
                } = e, u = (0, n.useRouter)(), d = (0, l.useRef)(), _ = (0, l.useRef)(null), p = (0, l.useRef)(null), f = (0, l.useRef)(), y = (0, l.useRef)(), v = (0, l.useRef)(null), g = (0, l.useRef)(null), b = (0, l.useRef)(), w = (0, h.uZ)(BaseScene, {
                    clearColor: "#101010"
                });
                (0, l.useImperativeHandle)(t, () => (0, s.Z)({
                    $element: v,
                    scene: w,
                    animateSet: C,
                    animateIn: T,
                    animateOut: M
                }), []);
                let x = (0, k.rE)(),
                    R = Global.mvs.glove;
                Global.activeMV = R;
                let N = (0, l.useCallback)(() => {
                    f.current && (f.current.x || (f.current.x = 0), f.current.x -= 2 * Render.HZ_MULTIPLIER, f.current.x %= y.current.offsetWidth, f.current.style.transform = "translateX(".concat(f.current.x, "px)"))
                }, []);
                (0, h.y2)(N);
                let C = () => {
                        var e, t, r, a, n, l;
                        null === (t = (e = _.current).animateSet) || void 0 === t || t.call(e), null === (a = (r = p.current).enable) || void 0 === a || a.call(r), null === (l = (n = g.current).animateSet) || void 0 === l || l.call(n)
                    },
                    T = () => {
                        var e, t, r, a;
                        null === (t = (e = _.current).animateIn) || void 0 === t || t.call(e), null === (a = (r = g.current).animateIn) || void 0 === a || a.call(r)
                    },
                    M = () => {
                        var e, t, r, a, n, l;
                        null === (t = (e = _.current).animateOut) || void 0 === t || t.call(e), null === (a = (r = p.current).disable) || void 0 === a || a.call(r), null === (l = (n = g.current).animateOut) || void 0 === l || l.call(n)
                    };
                return (0, l.useEffect)(() => {
                    var e, t, r;
                    R.highQuality || R.loadHighRes(), R.useVideo(), setBusState("arrowAction", () => {
                        u.push("/")
                    }), document.documentElement.style.setProperty("--primary", "#101010"), document.documentElement.style.setProperty("--secondary", "#FFD600"), Device.mobile ? null === (e = d.current) || void 0 === e || e.animateSet(1) : (null === (t = d.current) || void 0 === t || t.animateSet(), null === (r = d.current) || void 0 === r || r.animateIn(1450, "easeInOutCubic", 0, !0));
                    let a = async () => {
                        var e;
                        if (Stage.width < 1024) return;
                        let t = await (null === (e = d.current) || void 0 === e ? void 0 : e.gluiEl());
                        t.element.group.children[0].rotation.set(0, 0, -.15 * Math.PI)
                    };
                    a()
                }, []), (0, l.useEffect)(() => {
                    let e;
                    let t = async () => {
                        var e, t, r, a, n, l;
                        let s = (0, i.B)(VideoTexture, {
                            path: (null === (e = Device.mobile) || void 0 === e ? void 0 : e.phone) || (null === (t = Device.mobile) || void 0 === t ? void 0 : t.tablet) && Stage.width < Stage.height ? "images/reel_mobile.mp4" : "images/reel_desktop.mp4",
                            preload: !0
                        });
                        await s.texture.promise, s.start(), Global.video = s, Global.videoInView = !0, Global.videoDimensions = {
                            width: (null === (r = Device.mobile) || void 0 === r ? void 0 : r.phone) || (null === (a = Device.mobile) || void 0 === a ? void 0 : a.tablet) && Stage.width < Stage.height ? 750 : 512,
                            height: (null === (n = Device.mobile) || void 0 === n ? void 0 : n.phone) || (null === (l = Device.mobile) || void 0 === l ? void 0 : l.tablet) && Stage.width < Stage.height ? 1268 : 288
                        }, setBusState("video", Utils.timestamp())
                    };
                    return t(), () => {
                        var t;
                        return null == e ? void 0 : null === (t = e.destroy) || void 0 === t ? void 0 : t.call(e)
                    }
                }, []), (0, l.useEffect)(() => {
                    x && R && R && "android" !== Device.system.os && (R.draw = x)
                }, [x, R]), (0, a.jsx)(S.YR, {
                    scene: w,
                    children: (0, a.jsx)(O.Z, {
                        ref: b,
                        children: (0, a.jsxs)("div", {
                            className: "page ".concat(o().contact),
                            ref: v,
                            children: [(0, a.jsx)(I.Z, {
                                active: "/contact" === u.current,
                                className: o()["contact--bg"]
                            }), (0, a.jsxs)(q.Zs, {
                                className: o().contact__content,
                                children: [(0, a.jsxs)("div", {
                                    className: o().contact__header,
                                    children: [(0, a.jsx)("div", {
                                        className: o()["contact__header--title-wrapper"],
                                        children: (0, a.jsx)(D, {
                                            className: o()["contact__header--title"],
                                            asset: r.contactHeading.contactTitle
                                        })
                                    }), (0, a.jsx)(E.Z, {
                                        className: o()["contact__header--mv"],
                                        external: R,
                                        glui: {
                                            enable3D: !0
                                        },
                                        ref: d,
                                        zIndex: 0
                                    })]
                                }), (0, a.jsx)("div", {
                                    className: o().contact__body,
                                    children: (0, a.jsxs)("div", {
                                        className: o().contact__inner,
                                        children: [(0, a.jsxs)("div", {
                                            className: o()["contact__body--header"],
                                            children: [(0, a.jsx)(m.Z, {
                                                className: o()["marquee--bg"],
                                                glui: !0
                                            }), (0, a.jsx)(F, {
                                                className: o()["contact__body--header-inner"],
                                                text: "ACCEPTING NEW PROJECTS",
                                                glui: !0,
                                                color: "#ffD600",
                                                ref: p
                                            })]
                                        }), (0, a.jsxs)("div", {
                                            className: o()["contact__body--links"],
                                            children: [(0, a.jsxs)("div", {
                                                className: o()["contact__body--links-wrapper"],
                                                children: [(0, a.jsx)(c.Z, {
                                                    className: o()["contact__body--section-subtitle"],
                                                    text: "WANNA jam on A PROJECT TOGETHER?",
                                                    glui: !0
                                                }), (0, a.jsx)(c.Z, {
                                                    className: o()["contact__body--section-subtitle"],
                                                    text: "wanna catch up for a chat? A coffee? A beer?",
                                                    glui: !0
                                                }), (0, a.jsx)(c.Z, {
                                                    className: o()["contact__body--section-subtitle"],
                                                    text: "Think you'd make a good butterhead?",
                                                    glui: !0
                                                })]
                                            }), (0, a.jsx)(j, {
                                                ref: _
                                            })]
                                        })]
                                    })
                                })]
                            }), (0, a.jsx)(q.Zs, {
                                children: (0, a.jsx)(Z.Z, {
                                    page: "contact",
                                    ref: g
                                })
                            })]
                        })
                    })
                })
            };
            H.displayName = "Contact";
            var U = !0,
                G = (0, l.forwardRef)(H)
        },
        8477: function(e, t, r) {
            "use strict";
            var a = r(6038);
            t.Z = e => () => ({
                entryTransition: async t => {
                    var r, n, l;
                    let {
                        rootScene: s,
                        delay: u = 0,
                        first: o
                    } = t;
                    a.p8.set(e.$element.current, {
                        opacity: 0
                    }), null === (r = e.animateSet) || void 0 === r || r.call(e, o);
                    let i = null == e ? void 0 : null === (n = e.scene) || void 0 === n ? void 0 : n.current;
                    if (i && s) {
                        let e = await i;
                        Global.scene = e, s.setTo(e.rt), s.navigate(o)
                    }
                    return null === (l = e.animateIn) || void 0 === l || l.call(e, o), a.p8.to(e.$element.current, {
                        opacity: 1,
                        duration: 1.15,
                        ease: "Cubic.easeInOut",
                        delay: u,
                        onComplete: () => {
                            var t;
                            null === (t = e.onAnimateInComplete) || void 0 === t || t.call(e, o)
                        }
                    })
                },
                exitTransition: t => {
                    var r;
                    let {
                        to: n,
                        delay: l
                    } = t;
                    return null === (r = e.animateOut) || void 0 === r || r.call(e), a.p8.to(e.$element.current, {
                        opacity: 0,
                        duration: 1.15,
                        ease: "Cubic.easeInOut",
                        delay: l
                    })
                }
            })
        },
        2797: function(e) {
            e.exports = {
                root: "Background_root__AbScr"
            }
        },
        9162: function(e) {
            e.exports = {
                "enquiry-form": "EnquiryForm_enquiry-form__thIB5",
                "enquiry-form__form": "EnquiryForm_enquiry-form__form__9I6Uz",
                "ios-fix": "EnquiryForm_ios-fix____bRc",
                "enquiry-form__fake-label": "EnquiryForm_enquiry-form__fake-label__1ZroS",
                input: "EnquiryForm_input__KdEKc",
                "input--company": "EnquiryForm_input--company__vD71m",
                "input--message": "EnquiryForm_input--message__HGZ9b",
                "input-border": "EnquiryForm_input-border__lAGuy",
                "enquiry-form__btns": "EnquiryForm_enquiry-form__btns__IfByK",
                "enquiry-form__footer": "EnquiryForm_enquiry-form__footer__0oN3M"
            }
        },
        4884: function(e) {
            e.exports = {
                "notice-wrapper": "EnquiryFormNotice_notice-wrapper__QzaOc",
                notice: "EnquiryFormNotice_notice__p8_3c",
                "notice--error": "EnquiryFormNotice_notice--error__wyRyd"
            }
        },
        1928: function(e) {
            e.exports = {
                glb: "GLUIButton_glb__Jt12K",
                "glb-text": "GLUIButton_glb-text__jHkvg",
                "glb-bg": "GLUIButton_glb-bg__zYB5c",
                "glb-bg--bordered": "GLUIButton_glb-bg--bordered__xa7xQ",
                "glb-bg--mask": "GLUIButton_glb-bg--mask__7_5Y5",
                "glb--bordered": "GLUIButton_glb--bordered__2amnF",
                "glb-arrow": "GLUIButton_glb-arrow__H9L2F"
            }
        },
        375: function(e) {
            e.exports = {
                marquee: "MarqueeContact_marquee__Ol3mY",
                "marquee--bg": "MarqueeContact_marquee--bg__WWJaA",
                "marquee--inner": "MarqueeContact_marquee--inner__0s_Rq"
            }
        },
        3029: function(e) {
            e.exports = {
                wrapper: "MarqueeMSDF_wrapper__khhtJ",
                img: "MarqueeMSDF_img__QdD1q"
            }
        },
        7305: function(e) {
            e.exports = {
                "newsletter-signup": "NewsLetterSignup_newsletter-signup__tV2AB",
                "ios-fix": "NewsLetterSignup_ios-fix__YOBkC",
                "newsletter-signup-arrow": "NewsLetterSignup_newsletter-signup-arrow___xhn3",
                "newsletter-signup-border": "NewsLetterSignup_newsletter-signup-border__ohkAm",
                "newsletter-signup-fakecopy": "NewsLetterSignup_newsletter-signup-fakecopy__tmhlC",
                "newsletter-signup--form": "NewsLetterSignup_newsletter-signup--form__ijWKu",
                "newsletter-signup--submit": "NewsLetterSignup_newsletter-signup--submit__JIfkQ"
            }
        },
        3196: function(e) {
            e.exports = {
                contact: "contact_contact__GLH2Q",
                "contact--bg": "contact_contact--bg__HysJK",
                contact__content: "contact_contact__content__CiP4m",
                contact__header: "contact_contact__header__sng_l",
                "contact__header--mv": "contact_contact__header--mv__s7YSi",
                contact__inner: "contact_contact__inner__RI3z_",
                contact__body: "contact_contact__body__EmhOJ",
                "contact__body--header": "contact_contact__body--header__QQxnH",
                "marquee--bg": "contact_marquee--bg__F83p0",
                "contact__body--header-inner": "contact_contact__body--header-inner___X_TD",
                "contact__body--section": "contact_contact__body--section__5H5g9",
                "contact__body--section-last": "contact_contact__body--section-last__RvFZt",
                "contact__body--section-title": "contact_contact__body--section-title__SZbOW",
                "contact__body--section-subtitle": "contact_contact__body--section-subtitle__lwmx6",
                "contact__body--links": "contact_contact__body--links__Iu6Fd",
                "contact__body--links-wrapper": "contact_contact__body--links-wrapper__FDk8a",
                "contact__body--line": "contact_contact__body--line___fJjh",
                contact__footer: "contact_contact__footer__bkSxN",
                "contact__footer--copy": "contact_contact__footer--copy__cTYXk",
                "contact__footer--cta": "contact_contact__footer--cta__VIHVF"
            }
        }
    },
    function(e) {
        e.O(0, [671, 774, 888, 179], function() {
            return e(e.s = 7803)
        }), _N_E = e.O()
    }
]);