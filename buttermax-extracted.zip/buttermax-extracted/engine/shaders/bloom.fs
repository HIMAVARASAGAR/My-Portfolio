uniform sampler2D tBloom0;
uniform sampler2D tBloom1;
uniform sampler2D tBloom2;
uniform sampler2D tBloom3;
uniform float uBloomAddStrength;

void applyBloom(inout vec4 texel, vec2 uv) {
    vec3 c = vec3(0.0);
    c += texture2D(tBloom0, uv).rgb;
    c += texture2D(tBloom1, uv).rgb;
    c += texture2D(tBloom2, uv).rgb;
    c += texture2D(tBloom3, uv).rgb;

    c = clamp(c, 0.0, 1.0);

    texel.rgb += c * uBloomAddStrength;
}