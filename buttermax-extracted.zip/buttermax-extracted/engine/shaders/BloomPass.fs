#require(bloom.fs)

void main() {
    gl_FragColor = texture2D(tDiffuse, vUv);
    applyBloom(gl_FragColor, vUv);
}