#!ATTRIBUTES

#!UNIFORMS
uniform float uTransition;

#!VARYINGS
varying vec2 vUv;

#!SHADER: Vertex
void main() {
    vec3 pos = position;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
}

#!SHADER: Fragment
void main() {
    vec3 color = vec3(16./255.);
    gl_FragColor = vec4(color, uTransition);   
}