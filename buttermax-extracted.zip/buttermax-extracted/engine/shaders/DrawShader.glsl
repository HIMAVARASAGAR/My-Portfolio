#!ATTRIBUTES

#!UNIFORMS
uniform sampler2D tSource;
uniform vec2 uPosition;
uniform vec2 uResolution;
uniform float uSharp;
uniform float uSize;
uniform float uTrail;
uniform float uVelocity;
uniform vec2 uMouseMove;

uniform sampler2D tFluidMask;

#!VARYINGS
varying vec2 vUv;

#!SHADER: Vertex
void main() {
    vUv = uv;
    gl_Position = vec4(position, 1.0);
}

#!SHADER: Fragment

void main() {
    vec2 uv = gl_FragCoord.xy / uResolution.xx;

    vec2 uv2 = vUv;
    uv2.y += uVelocity * smoothstep(0.8, 0.05, length(uMouseMove-uv)) * 0.004;

    float fluidMask = 0.;

    #test Tests.useFluids()
        fluidMask = texture2D(tFluidMask, uv2).r;
    #endtest

    float trail = texture2D(tSource, uv2).r * uTrail;

    vec2 mousePos = vec2(uPosition.x, uResolution.y - uPosition.y) / uResolution.xx;

    float sharp = uSharp * 0.5;
    float circleDist = smoothstep(0. + sharp, 1. - sharp, min(distance(mousePos, uv ) / uSize * 20., 1.));

    gl_FragColor = vec4(vec3(1. - circleDist), 1.);

    gl_FragColor.r += trail;
    gl_FragColor.g = fluidMask;
}