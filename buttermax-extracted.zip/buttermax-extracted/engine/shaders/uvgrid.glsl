#require(transformUV.glsl)

vec2 getUVForGrid(vec2 uv, float xr, float yr, float x, float y) {
    return translateUV(scaleUV(uv, vec2(xr, yr), vec2(0.0)), -vec2(x / xr, y / yr));
}
