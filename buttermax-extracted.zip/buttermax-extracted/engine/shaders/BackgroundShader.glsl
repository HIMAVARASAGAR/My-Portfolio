#!ATTRIBUTES

#!UNIFORMS
uniform vec3 uColor;
uniform float uVelocity;

#!VARYINGS
varying vec2 vUv;

#!SHADER: Vertex
void main() {
    vUv = uv;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}

#!SHADER: Fragment

void main() {
    // vec2 st = vUv;

    vec3 color = uColor;


    color += uVelocity * 0.1;

    gl_FragColor = vec4(uColor, 1.0);
}