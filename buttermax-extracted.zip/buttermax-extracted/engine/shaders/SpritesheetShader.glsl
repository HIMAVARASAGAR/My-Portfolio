#!ATTRIBUTES

#!UNIFORMS
uniform sampler2D tMap;

#!VARYINGS
varying vec2 vUv;

#!SHADER: Vertex
void main() {
    gl_Position = vec4(position, 1.0);

    vUv = uv;
}

#!SHADER: Fragment

#require(uvgrid.glsl)

void main() {
    vec2 uv = vUv;

    float gridWidth = 8.0;
    float gridHeight = 8.0;

    float index =  mod(time * 25., gridWidth * gridHeight);
    index = floor(index);

    float xOffset = mod(index, gridHeight);
    float yOffset = floor(index / gridHeight); 

    yOffset = gridHeight - 1.0 - yOffset;

    uv = getUVForGrid(uv, gridWidth, gridHeight, xOffset, yOffset);

    vec3 color = texture2D(tMap, uv).rgb;

    gl_FragColor = vec4(color, 1.);
}