#!ATTRIBUTES

#!UNIFORMS
uniform vec4 uMaskValues;

#!VARYINGS

#!SHADER: Vertex
void main() {
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}

#!SHADER: Fragment
#require(range.glsl)

vec2 getMaskUV() {
    vec2 ores = gl_FragCoord.xy / resolution;
    vec2 uv;
    uv.x = range(ores.x, uMaskValues.x, uMaskValues.z, 0.0, 1.0);
    uv.y = 1.0 - range(1.0 - ores.y, uMaskValues.y, uMaskValues.w, 0.0, 1.0);
    return uv;
}

void main() {
    vec2 uv = getMaskUV();
    if(uv.x > 1.0) discard;
    gl_FragColor = vec4(uv, 1.0, 1.0);
}