#!ATTRIBUTES

#!UNIFORMS
uniform sampler2D tMap;
uniform sampler2D tMotion;
uniform float uProgress;
uniform float uColumns;
uniform float uRows;
uniform float uDisplacementStrength;

#!VARYINGS
varying vec2 vUv;

#!SHADER: Vertex
void main() {
    vec3 pos = position;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
    vUv = uv;
}

#!SHADER: Fragment
#require(range.glsl)

vec2 getSubUV(sampler2D _tMap, vec2 _dimensions, vec2 _uv, float _index) {
    float index = _index * (1.0 / _dimensions.x);
    vec2 uv = _uv;
    uv /= _dimensions;
    uv.y += (1.0 / _dimensions.y) * (_dimensions.y - 1.0);
    uv.x += floor(fract(index) * _dimensions.x) / _dimensions.x;
    uv.y -= floor(fract(index / _dimensions.y) * _dimensions.y) / _dimensions.y;
    return uv;
}

vec2 remap(vec2 _displacement, float displacementStrength) {
    vec2 displacement;
    displacement.r = crange(_displacement.r, 0.0, 1.0, -1.0, 1.0);
    displacement.g = crange(_displacement.g, 0.0, 1.0, -1.0, 1.0);
    return displacement * displacementStrength;
}

void main() {
    float MAX_INDEX = uColumns * uRows - 1.0;
    float index = crange(uProgress, 0.0, 1.0, 1.0, MAX_INDEX);

    float blend = fract(index);
    float displacementStrength = uDisplacementStrength * 0.01;

    vec2 dimensions = vec2(uColumns, uRows);
    vec2 subUv = getSubUV(tMap, dimensions, vUv, index);
    vec2 subUvNext = getSubUV(tMap, dimensions, vUv, index + 1.0);

    vec2 displacement = texture2D(tMotion, subUv).rg;
    displacement = remap(displacement, displacementStrength);

    vec2 displacementNext = texture2D(tMotion, subUvNext).rg;
    displacementNext = remap(displacementNext, displacementStrength);

    vec4 color = texture2D(tMap, subUv - displacement * blend);
    vec4 colorNext = texture2D(tMap, subUvNext + displacementNext * (1.0 - blend));
    color = mix(color, colorNext, blend);

    #ifdef LOOP
        index = crange(fract(time * 0.25), 0.0, 1.0, 1.0, MAX_INDEX);

        blend = fract(index);

        subUv = getSubUV(tMap, dimensions, vUv, index);
        subUvNext = getSubUV(tMap, dimensions, vUv, index + 1.0);

        displacement = texture2D(tMotion, subUv).rg;
        displacement = remap(displacement, displacementStrength);

        displacementNext = texture2D(tMotion, subUvNext).rg;
        displacementNext = remap(displacementNext, displacementStrength);

        color = texture2D(tMap, subUv - displacement * blend);
        colorNext = texture2D(tMap, subUvNext + displacementNext * (1.0 - blend));
        color = mix(color, colorNext, blend);
    #endif

    #ifdef LOOPFRAMES
        index = crange(fract(time * 0.25), 0.0, 1.0, 1.0, MAX_INDEX);

        subUv = getSubUV(tMap, dimensions, vUv, index);
        color = texture2D(tMap, subUv);
    #endif

    #ifdef LOOPCROSSFADE
        index = crange(fract(time * 0.25), 0.0, 1.0, 1.0, MAX_INDEX);

        blend = fract(index);

        subUv = getSubUV(tMap, dimensions, vUv, index);
        subUvNext = getSubUV(tMap, dimensions, vUv, index + 1.0);

        color = texture2D(tMap, subUv);
        colorNext = texture2D(tMap, subUvNext);
        color = color * (1.0 - blend) + colorNext * (blend);
    #endif

    #ifdef LOOPMOTIONVECTORS
        index = crange(fract(time * 0.25), 0.0, 1.0, 1.0, MAX_INDEX);

        subUv = getSubUV(tMotion, dimensions, vUv, index);
        color = texture2D(tMotion, subUv);
    #endif


    gl_FragColor = color;
}