#!ATTRIBUTES

#!UNIFORMS
uniform sampler2D tMap;
uniform float uBloomMinLuma;

#!VARYINGS
varying vec2 vUv;

#!SHADER: BloomQuad.vs
void main() {
    vUv = uv;
    gl_Position = vec4(position, 1.0);
}

#!SHADER: BloomQuad.fs

#require(luma.fs)

void main() {
    gl_FragColor = texture2D(tMap, vUv);

    gl_FragColor *= step(uBloomMinLuma, luma(gl_FragColor));
}