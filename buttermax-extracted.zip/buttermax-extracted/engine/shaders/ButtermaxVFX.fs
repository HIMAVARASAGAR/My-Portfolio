
uniform float uRGBStrength;
uniform float uExposure;
uniform float uVelocity;
uniform vec2 uMouseMove;
uniform float uBloomStrength;
uniform sampler2D uRT;
uniform vec3 uPeakColor;

#require(UnrealBloom.fs)
#require(simplenoise.glsl)
#require(HydraBloom.glsl)
#require(rgbshift.fs)
#require(rgb2hsv.fs)
#require(transformUV.glsl)
#require(blendmodes.glsl)

vec3 uncharted2Tonemap(vec3 x) {
  float A = 0.15;
  float B = 0.50;
  float C = 0.10;
  float D = 0.20;
  float E = 0.02;
  float F = 0.30;
  return ((x * (A * x + C * B) + D * E) / (x * (A * x + B) + D * F)) - E / F;
}

vec3 uncharted2(vec3 color) {
  const float W = 11.2;
  float exposureBias = 10.0;
  vec3 curr = uncharted2Tonemap(exposureBias * color);
  vec3 whiteScale = 1.0 / uncharted2Tonemap(vec3(W));
  return curr * whiteScale;
}

vec3 unreal(vec3 x) {
  return x / (x + 0.155) * 1.019;
}

vec3 hueShift(vec3 color, float hue) {
    const vec3 k = vec3(0.57735, 0.57735, 0.57735);
    float cosAngle = cos(hue);
    return vec3(color * cosAngle + cross(k, color) * sin(hue) + k * dot(k, color) * (1.0 - cosAngle));
}

float rand(vec2 co){
    return fract(sin(dot(co, vec2(12.9898, 78.233))) * 43758.5453);
}

vec3 czm_saturation(vec3 rgb, float adjustment)
{
    // Algorithm from Chapter 16 of OpenGL Shading Language
    const vec3 W = vec3(0.2125, 0.7154, 0.0721);
    vec3 intensity = vec3(dot(rgb, W));
    return mix(intensity, rgb, adjustment);
}


void main() {
    vec2 uv = vUv;
    uv = scaleUV(uv, vec2(1.0 + abs(uVelocity) * 0.001));
    float warp = - uVelocity * smoothstep(0.8, 0.05, abs(uMouseMove.x-uv.x)) * 0.0025;

    vec2 warpUV = uv;
    warpUV.y += uVelocity * 0.02;
    warp += sin(length(uMouseMove-warpUV) * 30.0 * smoothstep(0.0, 1.0, length(uMouseMove-warpUV))) * 0.0002 * abs(uVelocity) * (1.0-smoothstep(1.4, 0.5, length(uMouseMove-warpUV)));
    uv.y += warp;

    //float edges = smoothstep(0.5, 0.45, abs(vUv.y-0.5));
    //uv = mix(uv, vUv, 1.0-edges);]

    float edges = step(0.51, abs(uv.y-0.5));
    //edges = max(edges, step(0.5, abs(uv.x-0.5)));
    //uv.x = mix(uv.x, 1.0-uv.x, edges);
    
    uv = scaleUV(uv, vec2(mix(1.0, 1.15, edges)));
    uv.y += mod(uv.y + sin(uv.x * 5.0 + time * 0.5) * 0.01, (resolution.y * 0.000008)) * edges * abs(uVelocity);

    vec4 color = getRGB(tDiffuse, uv, mix(radians(-90.0), 0.0, edges), 0.0002 + warp * 0.1 + edges * 0.002 + uVelocity * 0.00005);
    
  
    //color.rgb *= mix(1.0, 0.8, edges);


    // vec3 bloom = getUnrealBloom(vUv).rgb;
    // color.rgb = pow(color.rgb, vec3(2.2));
    // color.rgb += pow(bloom, vec3(2.2)) * uBloomStrength;
    // color.rgb = pow(color.rgb, vec3(0.45));

    // float top = 1.0-step(warp, uv.y);
    // float bottom = 1.0-step(warp, uv.y);
    // float peak = bottom;//mix(top, bottom, step(0.0, uVelocity));
    color.rgb = mix(color.rgb, uPeakColor, edges);

    //color.rgb += (0.5-getNoise(vUv, time)) * 0.03;

    gl_FragColor = color;

    #test Tests.debugHitarea()
      vec4 rt = texture2D(uRT, gl_FragCoord.xy / resolution);
      gl_FragColor = color;
      gl_FragColor += rt;
    #endtest
    
    gl_FragColor.a = 1.0;
}