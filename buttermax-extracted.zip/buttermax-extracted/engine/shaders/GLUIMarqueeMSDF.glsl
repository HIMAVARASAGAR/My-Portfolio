precision highp float;
#!ATTRIBUTES

#!UNIFORMS
uniform sampler2D tMSDF;
uniform vec2 uResolution;
uniform vec2 uMapResolution;
uniform sampler2D tDraw;
uniform float uRotation;
uniform float uHorizontal;

#!VARYINGS
varying vec2 vUv;
varying vec3 vPos;

#!SHADER: Vertex

void main() {
  vec3 pos = position;

  gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
  vUv = uv;
  vPos = pos;
}

#!SHADER: Fragment
#require(transformUV.glsl)
#require(roundedBorder.glsl)
#require(rgb2hsv.fs)
#require(msdf.glsl)

void main() {
    float fluid = 0.;
    #test Tests.useFluids()
        vec3 drawer = texture2D(tDraw, gl_FragCoord.xy / resolution.xy).rgb;
        fluid = drawer.r + drawer.g;
        // fluid = drawer.r; // trail pointer
        // fluid = drawer.g; // fluid simulation
        // fluid = drawer.b; // pointer
    #endtest


    vec2 stR = uResolution.xy / uMapResolution;
    float m = max(stR.x, stR.y);
    vec2 uv = vUv - 0.5;
    uv *= stR;
    uv *= 1.0 / m;
    uv += 0.5;

    // uv = mod(uv, 0.33333);
    if (uHorizontal > 0.) {
      uv.x += time * 0.2;
    } else {
      uv.y += -time * 0.2;
    }

    uv = scaleUV(uv, vec2(1.5));
    uv = rotateUV(uv, uRotation);

    vec3 color = vec3(16.0 / 255.0);

    #test Tests.useFluids()
      color = mix(color, vec3(1.0, 214.0 / 255.0, 0.0), step(0.5, fluid * 2.));
        // alpha = step(0.5, fluid * 2. * inside);
    #endtest


    float alpha = msdf(tMSDF, uv);

    gl_FragColor = vec4(color, alpha);
}