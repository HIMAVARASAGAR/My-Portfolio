uniform sampler2D tFrom;
uniform sampler2D tTo;
uniform sampler2D tDraw;

uniform vec3 uPointerColor;
uniform vec2 uMousePosition;
uniform vec2 uMouseMove;

uniform float uTransition;
uniform float uPointerAlpha;
uniform float uBend;
uniform float uFirst;

uniform float uBlur;
uniform float uSize2;
uniform float uZoom;
uniform float uVelocity;

varying vec2 vUv;

#require(range.glsl)
#require(transformUV.glsl)
#require(rgb2hsv.fs)

float createDot(vec2 uv, vec2 transition, float size, float blur) {
    vec2 repeat = vec2(3., 3.);
    vec2 uvMod = mod(uv + transition, repeat) - repeat*0.5;
    return 1. - smoothstep(size - blur - 0.02, size + blur + 0.02, length(uvMod));
}

float circleExp(vec2 position, float scale) {
    vec2 normalizedScreen = vec2(resolution.x/resolution.y, 1.0);
    vec2 uv = gl_FragCoord.xy/resolution.y;
    vec2 offset = vec2(position.x, 1. - position.y) * normalizedScreen;
    vec2 circleCenter = offset;
    float circleRadius = 0.2 * scale;
    float distanceToCenter = length(uv - circleCenter);
    float edgeSmoothness = 0.8;
    float circle = 1.0 - smoothstep(circleRadius - edgeSmoothness, circleRadius, distanceToCenter);
    return circle;
}


vec2 applyCRTEffect(vec2 uv, float barrelAmount, float pincushionAmount)
{
    if (barrelAmount > 0. || pincushionAmount > 0.) { 
        uv = 2.0 * uv - 1.0;
        uv *= 1.0 + length(uv) * barrelAmount;
        uv = 0.5 * (uv + 1.0);

        uv = uv * 2.0 - 1.0;
        uv *= 1.0 + uv.x * uv.x * pincushionAmount;
        uv = 0.5 * (uv + 1.0);
    }

    return uv;
}

vec3 rgbShift(sampler2D tDiffuse, vec2 uv, float angle, float amount) {
    vec2 offset = vec2(cos(angle), sin(angle)) * amount;
    float r = texture2D(tDiffuse, uv + offset).r;
    float g = texture2D(tDiffuse, uv).g;
    float b = texture2D(tDiffuse, uv - offset).b;
    return vec3(r, g, b);
}

void main() {
    vec3 color;
    const float uTimeWithTransition = 1.0;
    const float uTimeStrength = 0.5;
    const float uSize = 1.;
    const float uSize0 = 0.35;
    const float uSize1 = 0.35;
    const float uBlur0 = 0.55;
    const float uBlur1 = 0.55;
    const float uBlur2 = 0.;
    const float uSwing = 0.;
    const float uSwingX = 0.;
    const float uSwingY = 0.;
    const float uSwingXY = 0.;
    const float uSwingBlur = 0.;

    vec2 screenUV = (gl_FragCoord.xy / resolution.xy);
    float ratio = resolution.x / resolution.y;
    vec2 squareUV = vUv / vec2(1., ratio);
    vec2 uv = vUv;
    color = vec3(0.);

    vec2 mousePos = uMousePosition;//mix(uMousePosition, vec2(0.5), smoothstep(0.3, 0.5, abs(length(0.5-uTransition))));
    mousePos = mix(mousePos, vec2(0.5), uFirst);

    // Dot Transition
    float zoom = uZoom;
    float dots = -0.1;
    vec2 dotUV = scaleUV(squareUV, vec2(1.0 + uTransition * 1.0), mousePos);
    vec2 uvMod = mix(applyCRTEffect(squareUV, .1, -.1), dotUV, uTransition) * zoom;
    float dotx = 0.;
    float iTime = mix(sin(time * uTimeStrength), uTransition * uTimeStrength, uTimeWithTransition);
    float size = uSize;
    size = uSize * crange(uTransition, 0., 1., 0., 2.0);
    dotx = circleExp(mousePos, crange(uTransition, 0.,1., 0., 15.));
    float sizeDotX =size * dotx;
    float bb1 = uBlur0 * uBlur;
    float bb2 = uBlur1 * uBlur;
    float bb3 = uBlur2 * uBlur;
    float size1 = uSize0 *sizeDotX;
    float size2 = uSize1 *sizeDotX;
    float size3 = uSize2 *sizeDotX;

    for(float i = 0.0; i < 3.; i++) {
        vec2 PLEASE_TAKE_CARE_OF_REPETITIONS = uvMod + vec2(i, 0.);
        dots += createDot(PLEASE_TAKE_CARE_OF_REPETITIONS, vec2(0., i), size1, bb1);
        dots += createDot(PLEASE_TAKE_CARE_OF_REPETITIONS, vec2(1., i), size2, bb2);
        dots += createDot(PLEASE_TAKE_CARE_OF_REPETITIONS, vec2(2. , i), size3, bb3);
    }

    dots *= smoothstep(1.0, 0.6, uTransition);

    vec2 scaleOrigin = mousePos;
    scaleOrigin = mix(scaleOrigin, vec2(0.5), 0.2);
    scaleOrigin.y += 0.2 - uTransition * 0.5;

    vec2 uvFrom = mix(uv, applyCRTEffect(uv, 0.1, -.1), uTransition);
    uvFrom = scaleUV(uvFrom, vec2(1.0 + uTransition * 1.2), scaleOrigin);
    uvFrom = rotateUV(uvFrom, -uTransition*mousePos.x*0.3);

    vec2 uvTo = mix(applyCRTEffect(uv, -0.1, 0.1), uv, uTransition);
    scaleOrigin.y -= uTransition * 0.5;
    uvTo = scaleUV(uvTo, vec2(0.6 + uTransition * 0.4), scaleOrigin);
    uvTo = rotateUV(uvTo, (1.0-uTransition)*mousePos.x*0.3);

    vec3 rgbFrom = rgbShift(tFrom, uvFrom, radians(90.0), 0.01*uTransition + uVelocity * 0.0001);
    vec3 rgbTo = texture2D(tTo, uvTo).rgb;

    vec3 from = rgbFrom;
    if (from.rgb == vec3(0.0)) from.rgb = vec3(16./300.);
    vec3 to = rgbTo;

    #test !Device.mobile
        vec3 rainbow = vec3(1.0, 0.15, 0.15);
        rainbow = rgb2hsv(rainbow);
        rainbow.x += (0.5 + sin(time*0.2 - length(screenUV-mousePos) * 6.0 + uTransition * 5.0 + dots * 8.0 + dotx * 2.0));
        rainbow = hsv2rgb(rainbow);

        float offsetRainbow = mix(0.15, 0.1, smoothstep(0.2, 1.0, length(screenUV-mousePos)));
        float fadeRainbow = smoothstep(0.52, 0.2, uTransition);

        to = mix(to, rainbow, (1.0-step(0.5+offsetRainbow*fadeRainbow, dots + dotx * 0.5)));
    #endtest
    color = mix(from, to, step(0.5, dots + dotx * 0.5));
    
    gl_FragColor = vec4(color, 1.0);
}