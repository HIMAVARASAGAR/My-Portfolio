#!ATTRIBUTES

#!UNIFORMS
uniform sampler2D tDiffuse;

#!VARYINGS
varying vec2 vUv;

#!SHADER: Vertex
void main() {
    gl_Position = vec4(position, 1.0);
    vUv = uv;
}

    #!SHADER: Fragment
    #require(HydraBloom.glsl)
void main() {

    vec3 color = texture2D(tDiffuse, vUv).xyz;
    vec3 bloom = getHydraBloom(vUv);

    gl_FragColor = vec4(color + bloom, 1.0);
}
