#!ATTRIBUTES

#!UNIFORMS

#!VARYINGS
varying vec3 vPos;
varying vec2 vUv;

#!SHADER: Vertex
void main() {
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    vPos = position;
}

#!SHADER: Fragment
void main() {
    gl_FragColor = vec4( vPos * 0.5 + 0.5, 1.0);
}