#!ATTRIBUTES

#!UNIFORMS
uniform sampler2D tMap;
uniform vec2 uResolution;
uniform float uRadius;

#!VARYINGS
varying vec2 vUv;

#!SHADER: Vertex
void main() {
    gl_Position = vec4(position, 1.0);
    vUv = uv;
}

    #!SHADER: Fragment
void main() {

    vec2 c = vUv;
    vec2 pxSize = 1.0 / uResolution;
    vec2 halfPixel = 0.5 / uResolution;
    vec3 sum = vec3(0.0);

    vec3 weights = vec3(0.03125, 0.0625, 0.125);

    vec2 br = vUv - halfPixel;
    vec2 bl = vUv + vec2(halfPixel.x, -halfPixel.y);
    vec2 tr = vUv + halfPixel;
    vec2 tl = vUv + vec2(-halfPixel.x, halfPixel.y);

    vec3 A = texture2D(tMap, vUv + vec2(-1.0, -1.0) * pxSize).xyz * weights.x;
    vec3 B = texture2D(tMap, vUv + vec2(0.0, -1.0) * pxSize).xyz * weights.y;
    vec3 C = texture2D(tMap, vUv + vec2(1.0, -1.0) * pxSize).xyz * weights.x;

    vec3 D = texture2D(tMap, br).xyz * weights.z;
    vec3 E = texture2D(tMap, bl).xyz * weights.z;
    vec3 F = texture2D(tMap, vUv + vec2(-1.0, 0.0) * pxSize).xyz * weights.y;

    vec3 G = texture2D(tMap, vUv).xyz * weights.z;

    vec3 H = texture2D(tMap, vUv + vec2(1.0, 0.0) * pxSize).xyz * weights.y;
    vec3 I = texture2D(tMap, tl).xyz * weights.z;
    vec3 J = texture2D(tMap, tr).xyz * weights.z;

    vec3 K = texture2D(tMap, vUv + vec2(-1.0, 1.0) * pxSize).xyz * weights.x;
    vec3 L = texture2D(tMap, vUv + vec2(0.0, 1.0) * pxSize).xyz * weights.y;
    vec3 M = texture2D(tMap, vUv + vec2(1.0, 1.0) * pxSize).xyz * weights.x;

    sum = A + B + C + D + E + F + G + H + I + J + K + L + M;

    gl_FragColor = vec4(sum, 1.0);
}
