uniform vec2 uResolution;
uniform vec2 uDir;
uniform float uStrength;

#require(gaussianblur.fs)

void main() {
    gl_FragColor = blur5(tDiffuse, vUv, uResolution, uDir) * uStrength;
}