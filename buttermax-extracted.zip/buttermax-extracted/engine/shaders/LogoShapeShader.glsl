#!ATTRIBUTES

#!UNIFORMS
uniform sampler2D tMap;
uniform float uAlpha; 
uniform float uScroll; 
uniform vec2 uResolution;
uniform vec3 uColor;
uniform sampler2D tDraw;

#!VARYINGS
varying vec2 vUv;

#!SHADER: Vertex

void main() {
    vec3 pos = position;

    gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
    vUv = uv;
}

#!SHADER: Fragment

#require(rgb2hsv.fs)

void main() {
    #test Tests.useFluids()
        vec4 draw = texture2D(tDraw, gl_FragCoord.xy / resolution.xy);
        vec2 scaledUV = vUv + (draw.rr * 0.01);

        // scaledUV.x *= 0.5;
        scaledUV -= 0.5;
        scaledUV.y *= 0.25;
        scaledUV += 0.5;

        vec4 tex = texture2D(tMap, scaledUV + vec2(0.,  -uScroll));


        vec3 rainbow = vec3(1.0, 0.15, 0.15);
        rainbow = rgb2hsv(rainbow);
        rainbow.x += (0.5 + sin(time*10.0 + draw.r * 20.0 + draw.g * 20.0 + gl_FragCoord.x/resolution.x) * 6.0) * 0.08;
        rainbow = hsv2rgb(rainbow);

        tex.rgb = mix(uColor, rainbow, step(0.4, draw.g));
        tex.rgb = mix(tex.rgb, vec3(1.0), step(0.5, draw.g));

        // tex.rg = scaledUV;
        // tex.ba = scaledUV;

        // tex.rgb = mix(tex.rgb, uColor * 0.3, step(0.01, draw.g));
        // tex.rgb = mix(tex.rgb, uColor * 0.4, step(0.03, draw.g));
        // tex.rgb = mix(tex.rgb, uColor * 0.5, step(0.05, draw.g));
        // tex.rgb = mix(tex.rgb, uColor * 0.6, step(0.07, draw.g));
        // tex.rgb = mix(tex.rgb, uColor * 0.7, step(0.1, draw.g));
        // tex.rgb = mix(tex.rgb, uColor , step(0.5, draw.g + draw.r));
    #endtest

    #test !Tests.useFluids()
        vec4 tex = texture(tMap, vUv + vec2(0.0, -uScroll));
    #endtest

    vec4 color = tex;

    gl_FragColor = color;
    gl_FragColor.a *= uAlpha;
}