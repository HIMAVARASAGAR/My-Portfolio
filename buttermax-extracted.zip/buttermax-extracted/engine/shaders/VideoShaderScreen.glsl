#!ATTRIBUTES

#!UNIFORMS
uniform sampler2D tMap;
uniform vec2 pixelCoverage;
uniform float uBrightness;
uniform float uPow;
uniform sampler2D tFluid;
uniform sampler2D tFluidMask;

#!VARYINGS
varying vec2 vUv;
varying vec4 vScreenUV;

#!SHADER: Vertex.vs
void main() {
    vUv = uv;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);

    vScreenUV = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}

#!SHADER: Fragment.fs

#require(rgbshift.fs)

vec2 getFluidVelocity() {
    vec2 suv = gl_FragCoord.xy / resolution.xy;
    float fluidMask = smoothstep(0.1, 0.7, texture2D(tFluidMask, suv).r);
    return texture2D(tFluid, suv).xy * fluidMask;
}

vec3 getFluidVelocityMask() {
    vec2 suv = gl_FragCoord.xy / resolution.xy;
    float fluidMask = smoothstep(0.1, 0.7, texture2D(tFluidMask, suv).r);
    return vec3(texture2D(tFluid, suv).xy * fluidMask, fluidMask);
}

float sdRoundedBox( in vec2 f, in vec2 b, in vec4 r )
{
    vec2 c= vec2(1.);
    vec2 p = mod(f+0.5*c,c)-0.5*c;

    r.xy = (p.x>0.0)?r.xy : r.zw;
    r.x  = (p.y>0.0)?r.x  : r.y;
    vec2 q = abs(p)-b+r.x;
    return min(max(q.x,q.y),0.0) + length(max(q,0.0)) - r.x;
}

void main() {
    vec2 st = pixelCoverage.x * vUv;
    float _x = floor(st.x + 0.5);
    float m = mod(_x, 3.);
    vec3 multiplier = vec3(float(m == 0.), float(m == 1.), float(m == 2.));
    float val = sdRoundedBox(st, pixelCoverage.y * vec2(-0.1, -0.02), vec4(-0.2));

    vec2 screenUV = vScreenUV.xy * 0.15 + 0.5;
    screenUV.y += 0.2;

    vec3 fluidVel = texture2D(tFluid, screenUV).rgb;
    float fluidMask = texture2D(tFluidMask, screenUV).r;
    fluidMask = 1.0 - pow(1.0 - fluidMask, 6.2);

    vec2 videoUV = vUv;
    videoUV += fluidVel.xy * 0.02;

    vec4 tex = getRGB(tMap, videoUV, 0.1, fluidVel.x * 0.002);

    tex.rgb *= step(val, 0.5) * multiplier * uBrightness;
    tex.rgb = pow(tex.rgb, vec3(uPow));

    tex.a *= 0.9;

    //tex.a *= smoothstep(0.0, 0.2, tex.r);

    gl_FragColor = tex;
}