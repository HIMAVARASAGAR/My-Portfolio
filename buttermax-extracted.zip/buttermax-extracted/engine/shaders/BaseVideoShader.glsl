#!ATTRIBUTES

#!UNIFORMS
uniform vec3 uColor;
uniform vec3 uBGColor;
uniform float uAlpha; 
uniform sampler2D tDraw;
uniform float uScroll;
uniform sampler2D tMap;
uniform bool uFixed;
uniform float uVelocity;
uniform vec2 uMouseMove;
uniform float uDiscard;
uniform float uShadowed;
uniform vec2 uResolution;
uniform vec2 uMapResolution;

#!VARYINGS
varying vec2 vUv;

#!SHADER: Vertex
void main() {
    vec3 pos = position;

    gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);

    vUv = uv;
}

#!SHADER: Fragment

#require(range.glsl)
#require(rgbshift.fs)
#require(rgb2hsv.fs)
#require(simplenoise.glsl)
#require(blendmodes.glsl)
#require(transformUV.glsl)

void main() {
    vec2 uv = vUv;
    vec3 drawer;
    float fluid = 0.;

    float velocity = uVelocity;//pow(uVelocity, 3.0);

    #test Tests.useFluids()
        drawer = texture2D(tDraw, gl_FragCoord.xy / resolution.xy).rgb;
        fluid = drawer.g;
        // fluid = drawer.r; // trail pointer
        // fluid = drawer.g; // fluid simulation
        // fluid = drawer.b; // pointer
    #endtest

    uv.y -= uVelocity * smoothstep(0.8, 0.05, length(uMouseMove-uv)) * 0.002 * smoothstep(0.499, 0.3, abs(0.5-uv.y));
    uv.y -= velocity * mod(uv.y, (resolution.y * 0.00001)) * 0.1 * smoothstep(0.48, 0.45, abs(0.5-uv.y));

    //uv = scaleUV(uv, vec2(1.0 + velocity * 0.001));

    vec2 baseUV = uv;
    // vec2 oUV = uv;

    vec2 stR = uResolution.xy / uMapResolution.xy;
    float m = max(stR.x , stR.y);
    uv = baseUV - 0.5;
    uv *= stR;
    uv *= 1.0 / m;
    uv += 0.5;

    vec4 color = vec4(1.0);
    vec2 scaledUV = uv;

    #test !Device.mobile
        if(uShadowed > 0.0) {
            baseUV.x = 1.0-baseUV.x;
        }
    #endtest
    baseUV.y += uVelocity * smoothstep(0.8, 0.05, length(uMouseMove-uv)) * 0.02 * smoothstep(0.499, 0.3, abs(0.5-uv.y));

    baseUV += fluid * 0.05;//smoothstep(1.0, -1.0, length(uv-0.5));
    baseUV.y += fluid * 0.05 - mod(uv.y + sin(uv.x * 5.0 + time * 0.5) * 0.5 + fluid + sin(time * 0.3) * 2.5, (resolution.y * 0.00001)) * fluid;

    vec2 scalar = vec2(1.);
    if(uShadowed > 0.0) {
        scalar = vec2(1.2);
    }
    #test Device.mobile
        scalar = vec2(1.0);
    #endtest
    color = getRGB(tMap, scaleUV(baseUV, scalar), radians(90.0), - velocity * 0.0004 + fluid * 0.003);

    #test Device.mobile
        gl_FragColor = color;
        gl_FragColor.a *= uAlpha;

        return;
    #endtest

    vec3 noiseTex = vec3(getNoise(uv, time));

    vec2 innerUV = scaledUV;
    innerUV.y += uVelocity * 0.005;

    innerUV -= fluid * 0.05;//smoothstep(1.0, -1.0, length(uv-0.5));
    innerUV.y -= fluid * 0.15 - mod(uv.y + sin(uv.x * 5.0 + time * 0.5) * 0.5 + fluid + sin(time * 0.3) * 2.5, (resolution.y * 0.00001)) * fluid;

    innerUV.x += 0.015;

    vec2 scale = vec2(1.0);
    vec4 inner = getRGB(tMap, scaleUV(innerUV, scale), radians(90.0), velocity * 0.0006 + fluid * 0.003);

    if(uShadowed > 0.0) {
        color.rgb *= mix(0.5, 0.0, smoothstep(0.65, 0.2, length(innerUV-0.5)));
        color.rgb = mix(color.rgb, inner.rgb, step(0.12, innerUV.x) * step(0.12, 1.0-innerUV.x) * step(0.12, innerUV.y) * step(0.12, 1.0-innerUV.y));
        color.rgb *= mix(1.0, 0.98, fluid);
        color.rgb = blendOverlay(color.rgb, noiseTex, abs(velocity)*0.02 + step(0.5, fluid) * 4.0);
    }

    gl_FragColor = color;
    gl_FragColor.a *= uAlpha;
}