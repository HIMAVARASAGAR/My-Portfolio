#!ATTRIBUTES

#!UNIFORMS

uniform sampler2D tMap;
uniform sampler2D tDraw;
uniform vec2 uMouseMove;
uniform vec2 uResolution;
uniform vec2 uMapResolution;

uniform float uTrail;
uniform float uAlpha;

#!VARYINGS
varying vec2 vUv;
varying vec3 vPos;

#!SHADER: Vertex
void main() {
    vec3 pos = position;

    gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
    vUv = uv;
    vPos = pos;
}

#!SHADER: Fragment

#require(range.glsl)
#require(rgbshift.fs)
#require(rgb2hsv.fs)
#require(simplenoise.glsl)
#require(blendmodes.glsl)
#require(transformUV.glsl)

void main() {
    vec3 drawer;
    float fluid = 0.;
    
    #test Tests.useFluids()
        drawer = texture2D(tDraw, gl_FragCoord.xy / resolution.xy).rgb;
        fluid = drawer.g;
    #endtest

    vec2 stR = uResolution.xy / uMapResolution;
    float m = max(stR.x, stR.y);
    vec2 uv = vUv - 0.5;
    uv *= stR;
    uv *= 1.0 / m;
    uv += 0.5;
    vec4 tex = texture2D(tMap, uv);
    
    vec2 baseUV = uv;
    vec4 color = vec4(1.0);
    baseUV.x = 1.0-baseUV.x;
    
    baseUV += fluid * 0.05;//smoothstep(1.0, -1.0, length(uv-0.5));
    baseUV.y += fluid * 0.05 - mod(uv.y + sin(uv.x * 5.0 + time * 0.5) * 0.5 + fluid + sin(time * 0.3) * 2.5, (resolution.y * 0.00001)) * fluid;

    color = getRGB(tMap, scaleUV(baseUV, vec2(1.0 + 0.2 * uAlpha)), 0.0, fluid * 0.015);
    
    vec3 noiseTex = vec3(getNoise(uv, time));
    
    // vec2 innerUV = uv;
    // innerUV += uMouseMove;

    // innerUV -= fluid * 0.15;//smoothstep(1.0, -1.0, length(uv-0.5));
    // innerUV.y -= fluid * 0.15 - mod(uv.y + sin(uv.x * 5.0 + time * 0.5) * 0.5 + fluid + sin(time * 0.3) * 2.5, (resolution.y * 0.00001)) * fluid;

    // vec4 inner = getRGB(tMap, scaleUV(innerUV, vec2(0.8)), radians(90.0), fluid * 0.003);

    // color.rgb *= mix(0.5, 0.0, smoothstep(0.65, 0.2, length(innerUV-0.5)));
    // color.rgb = mix(color.rgb, inner.rgb, step(0.1, innerUV.x) * step(0.1, 1.0-innerUV.x) * step(0.1, innerUV.y) * step(0.1, 1.0-innerUV.y));
    color.rgb *= mix(1.0, 0.98, fluid);
    //color.rgb = blendOverlay(color.rgb, noiseTex, fluid * 1.0);

    if (uTrail >= 0.0 && uTrail < 1.0) {
        vec2 position = vUv - vec2(0.5);           
        float dist =  length(position * vec2(resolution.x/resolution.y, 1.0));

        float radius = uTrail;
        float mask = step(radius, dist);

        if (mask > 0.0) discard;
    }

    gl_FragColor.rgb = color.rgb;
    gl_FragColor.a = uAlpha;
}