#!ATTRIBUTES

#!UNIFORMS
uniform vec4 uBounds;
uniform vec3 uColor;
uniform float uAlpha;
uniform sampler2D tMap;

#!VARYINGS
varying vec2 vUv;

#!SHADER: Vertex
void main() {
    vUv = uv;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}

#!SHADER: Fragment
#require(msdf.glsl)

void main() {
    if (gl_FragCoord.x < uBounds.x || gl_FragCoord.x > uBounds.z) {
        discard;
        return;
    }
    float alpha = msdf(tMap, vUv);

    gl_FragColor.rgb = uColor;
    gl_FragColor.a = 1.0 * uAlpha;
}