uniform sampler2D tFrom;
uniform sampler2D tTo;

uniform vec2 uMouseMove;
uniform float uBend;
uniform float uVelocity;

uniform float uFirst;

varying vec2 vUv;

void main() {
    vec2 uv = vUv;
    vec3 color = vec3(0.);

    if (uBend > 0.) {
        vec2 center = vec2(0.5, 0.); 
        vec2 offset = uv - center;
        float distance = length(offset);
        float bend = max(uBend, 0.) * 2.;
        float distortion = bend * pow(distance, 2.0);
        uv.y += distortion * (1.0 - center.y);
    }

    uv.y -= uVelocity * smoothstep(0.8, 0.05, length(uMouseMove-uv)) * 0.002 * smoothstep(0.499, 0.3, abs(0.5-uv.y));
    
    color = texture2D(tFrom, uv).rgb;

    if (uFirst > 0.5) color = vec3(16./255.);
    gl_FragColor = vec4(color, 1.0);

}
