#!ATTRIBUTES

#!UNIFORMS
uniform sampler2D tMap;
uniform sampler2D tMapSpecular;
uniform sampler2D tMotion;
uniform float uProgress;
uniform float uColumns;
uniform float uRows;
uniform float uColumnsSpecular;
uniform float uRowsSpecular;
uniform float uDisplacementStrength;

#!VARYINGS
varying vec2 vUv;

#!SHADER: Vertex
void main() {
    vec3 pos = position;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
    vUv = uv;
}

#!SHADER: Fragment
#require(range.glsl)

vec2 getSubUV(sampler2D _tMap, vec2 _dimensions, vec2 _uv, float _index) {
    float index = _index * (1.0 / _dimensions.x);
    vec2 uv = _uv;
    uv /= _dimensions;
    uv.y += (1.0 / _dimensions.y) * (_dimensions.y - 1.0);
    uv.x += floor(fract(index) * _dimensions.x) / _dimensions.x;
    uv.y -= floor(fract(index / _dimensions.y) * _dimensions.y) / _dimensions.y;
    return uv;
}

vec2 remap(vec2 _displacement, float displacementStrength) {
    vec2 displacement;
    displacement.r = crange(_displacement.r, 0.0, 1.0, -1.0, 1.0);
    displacement.g = crange(_displacement.g, 0.0, 1.0, -1.0, 1.0);
    return displacement * displacementStrength;
}

void main() {
    float MAX_INDEX = uColumns * uRows - 1.0;
    float index = crange(uProgress, 0.0, 1.0, 1.0, MAX_INDEX);

    float blend = fract(index);
    float displacementStrength = uDisplacementStrength * 0.01;

    vec2 dimensions = vec2(uColumns, uRows);
    vec2 subUv = getSubUV(tMap, dimensions, vUv, index);
    vec2 subUvNext = getSubUV(tMap, dimensions, vUv, index + 1.0);

    vec2 displacement = texture2D(tMotion, subUv).rg;
    displacement = remap(displacement, displacementStrength);

    vec2 displacementNext = texture2D(tMotion, subUvNext).rg;
    displacementNext = remap(displacementNext, displacementStrength);

    vec3 color = texture2D(tMap, subUv - displacement * blend).rgb;
    vec3 colorNext = texture2D(tMap, subUvNext + displacementNext * (1.0 - blend)).rgb;
    color = mix(color, colorNext, blend);

    // specular layer
    float specMaxIndex = uColumnsSpecular * uRowsSpecular - 1.0;
    float specIndex = crange(uProgress, 0.0, 1.0, 1.0, specMaxIndex);

    float specBlend = fract(specIndex);

    vec2 dimensionsSpecular = vec2(uColumnsSpecular, uRowsSpecular);
    vec2 specSubUV = getSubUV(tMap, dimensionsSpecular, vUv, specIndex);
    vec2 specSubUVNext = getSubUV(tMap, dimensionsSpecular, vUv, specIndex + 1.0);

    // blend from one frame to the next
    vec3 specColor = texture2D(tMapSpecular, specSubUV).rgb;
    vec3 specColorNext = texture2D(tMapSpecular, specSubUVNext).rgb;
    specColor = mix(specColor, specColorNext, specBlend);

    color = pow(color, vec3(2.2));
    specColor = pow(specColor, vec3(2.2));
    color += specColor;
    color = pow(color, vec3(0.45));

    gl_FragColor = vec4(color, 1.0);
}