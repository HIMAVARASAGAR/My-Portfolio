#!ATTRIBUTES

#!UNIFORMS
uniform sampler2D tMap;
uniform sampler2D tDraw;
uniform float uParallax;
uniform vec2 uResolution;
uniform float uScale;
uniform float uMouseMove;
uniform float uVelocity;

#!VARYINGS
varying vec2 vUv;

#!SHADER: Vertex
void main() {
    vec3 pos = position;
    pos.y -= uVelocity * 0.005;


    gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
    vUv = uv;
}

#!SHADER: Fragment

#require(rgbshift.fs)
#require(transformUV.glsl)
#require(range.glsl)

void main() {
    vec2 uv = vUv;

    uv -= 0.5;
    uv *= uResolution.xy / uResolution.y;
    uv += 0.5;

    vec3 drawer;
    float fluid;
    #test Tests.useFluids()
        drawer = texture2D(tDraw, gl_FragCoord.xy / resolution.xy).rgb;
        fluid = drawer.r + drawer.g;
        // fluid = drawer.r; // trail pointer
        // fluid = drawer.g; // fluid simulation
        // fluid = drawer.b; // pointer
    #endtest

    fluid = smoothstep(0.3, 0.5, fluid);

    vec4 color = getRGB(tMap, uv, radians(90.0), fluid * 0.015);
    color *= 1.0 + fluid * 0.1;

    gl_FragColor = vec4(vec3(1.0 - fluid), color.a);
}