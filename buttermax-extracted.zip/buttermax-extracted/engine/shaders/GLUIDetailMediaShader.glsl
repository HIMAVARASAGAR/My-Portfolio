#!ATTRIBUTES

#!UNIFORMS
uniform sampler2D tMap;
uniform sampler2D tDraw;
uniform float uParallax;
uniform float uScale;
uniform float uMouseMove;
uniform float uVelocity;

#!VARYINGS
varying vec2 vUv;

#!SHADER: Vertex
void main() {
    vec3 pos = position;
    pos.y -= uVelocity * 0.005;


    gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
    vUv = uv;
}

#!SHADER: Fragment

#require(rgbshift.fs)
#require(range.glsl)

void main() {
    vec2 uv = vUv;

    vec3 drawer;
    float fluid;
    #test Tests.useFluids()
        drawer = texture2D(tDraw, gl_FragCoord.xy / resolution.xy).rgb;
        fluid = drawer.r + drawer.g;
        // fluid = drawer.r; // trail pointer
        // fluid = drawer.g; // fluid simulation
        // fluid = drawer.b; // pointer
    #endtest

    fluid = smoothstep(0.3, 0.5, fluid);

    if (uScale > 0.5) {
        uv += smoothstep(0.5, 0.4, abs(0.5-fluid)) * 0.1;
        uv.y += uVelocity * smoothstep(0.8, 0.05, length(uMouseMove-uv)) * 0.002 * smoothstep(0.499, 0.3, abs(0.5-uv.y));
        uv.y -= uVelocity * mod(uv.x, 0.01) * 0.2;

        uv += fluid * 0.02;//smoothstep(1.0, -1.0, length(uv-0.5));
        uv.y += fluid * 0.05 - mod(uv.y + sin(uv.x * 5.0 + time * 0.2) * 0.5 + fluid + sin(time * 0.15) * 2.5, 0.01 + fluid * 0.03) * fluid;
    }

    vec4 color = getRGB(tMap, uv, radians(90.0), uVelocity * 0.001 + fluid * 0.015);
    color *= 1.0 + fluid * 0.1;
    
    gl_FragColor = vec4(color.rgb, 1.0);
}