#!ATTRIBUTES
attribute vec2 local;

#!UNIFORMS

uniform sampler2D tMap;
uniform vec3 uColor;
uniform vec3 uColor2;
uniform float uAlpha;
uniform sampler2D tDraw;
uniform vec2 uBounds;
uniform float uOverflow;
uniform float uDPR;
uniform float uTranslate;
uniform float uTransition;
uniform float uType;
uniform float uActive;

#!VARYINGS
varying vec2 vUv;
varying vec2 vLocal;

#!SHADER: Vertex

void main() {
    vec3 pos = position;

    gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
    vUv = uv;
    vLocal = local;
}

#!SHADER: Fragment

#require(msdf.glsl)
#require(rgb2hsv.fs)

void main() {
   vec2 st = gl_FragCoord.xy * (1.0 / uDPR);

    if (uOverflow > 0.0) {
         if (st.x < uBounds.x || st.x > uBounds.y) discard;
    }
    
    gl_FragColor.rgb = uColor;

    bool showRainbow = true;
    
    #test Device.mobile
        showRainbow = false;
    #endtest
    
    #test Tests.useFluids()
        vec3 color = uColor;
        vec2 drawer = texture2D(tDraw, gl_FragCoord.xy / resolution.xy).rg;

        float fluid = drawer.r + drawer.g;
        float stepFluid = smoothstep(0.8, 1.0, fluid * 2.);
        float stepFluid2 = step(0.5, fluid * 2.);
        float stepFluid3 = step(0.8, fluid * 2.);

        if (showRainbow) {
            vec3 rainbow = rgb2hsv(vec3(1.0, 0.2, 0.2));
            rainbow.x -= time * 2.0 + fluid * 2.0 + st.x * 4.0;
            rainbow = hsv2rgb(rainbow);
            rainbow = mix(rainbow, vec3(1.0), stepFluid3);
            color = mix(uColor, rainbow, stepFluid2);
        }
    
        gl_FragColor.rgb = mix(color, uColor2, stepFluid);
    #endtest
    
    float alpha = msdf(tMap, vUv);
    if(uTransition < .99) { alpha *= uTransition; }

    // gl_FragColor.rgb = mix(uColor, uColor2, stepFluid);
    gl_FragColor.a = alpha * uAlpha;
}
