#!ATTRIBUTES

#!UNIFORMS
uniform sampler2D tMap;
uniform sampler2D tNext;
uniform vec2 uResolution;
uniform float uRadius;
uniform float uIntensity;
uniform vec3 uTint;

#!VARYINGS
varying vec2 vUv;

#!SHADER: Vertex
void main() {
    gl_Position = vec4(position, 1.0);
    vUv = uv;
}

    #!SHADER: Fragment
void main() {
    vec2 c = vUv;
    vec2 texelSize = (1.0 / uResolution) * uRadius;
    vec3 sum = vec3(0.0);

    sum += texture2D(tMap, vUv - texelSize).xyz * 0.0625;
    sum += texture2D(tMap, vUv + vec2(0.0, -texelSize.y)).xyz * 0.125;
    sum += texture2D(tMap, vUv + vec2(texelSize.x, -texelSize.y)).xyz * 0.0625;

    sum += texture2D(tMap, vUv - vec2(texelSize.x, 0.0)).xyz * 0.125;
    sum += texture2D(tMap, vUv).xyz * 0.25;
    sum += texture2D(tMap, vUv + vec2(texelSize.x, 0.0)).xyz * 0.125;

    sum += texture2D(tMap, vUv + texelSize).xyz * 0.0625;
    sum += texture2D(tMap, vUv + vec2(0.0, texelSize.y)).xyz * 0.125;
    sum += texture2D(tMap, vUv + vec2(-texelSize.x, texelSize.y)).xyz * 0.0625;

    vec3 next = texture2D(tNext, vUv).xyz;
    next += min(vec3(1.0), sum * uIntensity) * uTint;

    gl_FragColor = vec4(next, 1.0);
}
