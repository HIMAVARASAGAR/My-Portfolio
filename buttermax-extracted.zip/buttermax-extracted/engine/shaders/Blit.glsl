#!ATTRIBUTES

#!UNIFORMS
uniform sampler2D tMap;

#!VARYINGS
varying vec2 vUv;

#!SHADER: Vertex
void main() {
    gl_Position = vec4(position, 1.0);
    vUv = uv;
}

    #!SHADER: Fragment
void main() {
    #drawbuffer Color gl_FragColor = texture2D(tMap, vUv);
    #drawbuffer BloomMask gl_FragColor = vec4(1.0);
}
