uniform sampler2D tHydraBloom;

vec3 getHydraBloom(vec2 uv) {
    return texture2D(tHydraBloom, uv).rgb;
}
