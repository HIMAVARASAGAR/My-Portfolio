#!ATTRIBUTES

#!UNIFORMS
uniform vec3 uColor;

uniform vec2 uMousePosition;
uniform float uTransition;

uniform float uBlur;
uniform float uSize2;

varying vec2 vUv;

#!VARYINGS
varying vec2 vUv;

#!SHADER: Vertex
void main() {
    vec3 pos = position;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
    
    vUv = uv;
}

#!SHADER: Fragment

#require(range.glsl)
#require(transformUV.glsl)
#require(rgb2hsv.fs)

float createDot(vec2 uv, vec2 transition, float size, float blur) {
    vec2 repeat = vec2(3., 3.);
    vec2 uvMod = mod(uv + transition, repeat) - repeat*0.5;
    return 1. - smoothstep(size - blur - 0.02, size + blur + 0.02, length(uvMod));
}

float circleExp(vec2 position, float scale) {
    vec2 normalizedScreen = vec2(resolution.x/resolution.y, 1.0);
    vec2 uv = gl_FragCoord.xy/resolution.y;
    vec2 offset = vec2(position.x, 1. - position.y) * normalizedScreen;
    vec2 circleCenter = offset;
    float circleRadius = 0.2 * scale;
    float distanceToCenter = length(uv - circleCenter);
    float edgeSmoothness = 0.8;
    float circle = 1.0 - smoothstep(circleRadius - edgeSmoothness, circleRadius, distanceToCenter);
    return circle;
}


vec2 applyCRTEffect(vec2 uv, float barrelAmount, float pincushionAmount)
{
    if (barrelAmount > 0. || pincushionAmount > 0.) { 
        uv = 2.0 * uv - 1.0;
        uv *= 1.0 + length(uv) * barrelAmount;
        uv = 0.5 * (uv + 1.0);

        uv = uv * 2.0 - 1.0;
        uv *= 1.0 + uv.x * uv.x * pincushionAmount;
        uv = 0.5 * (uv + 1.0);
    }

    return uv;
}

void main() {
    vec3 color;
    const vec2 uMousePosition = vec2(0.5);
    const float uTimeWithTransition = 1.0;
    const float uTimeStrength = 0.5;
    const float uSize = 1.;
    const float uSize0 = 0.35;
    const float uSize1 = 0.35;
    const float uBlur0 = 0.55;
    const float uBlur1 = 0.55;
    const float uBlur2 = 0.;
    const float uSwing = 0.;
    const float uSwingX = 0.;
    const float uSwingY = 0.;
    const float uSwingXY = 0.;
    const float uSwingBlur = 0.;
    const float zoom = 8.;

    vec2 screenUV = (gl_FragCoord.xy / resolution.xy);
    float ratio = resolution.x / resolution.y;
    vec2 squareUV = vUv / vec2(1., ratio);
    vec2 uv = vUv;
    color = vec3(0.);

    vec2 mousePos = uMousePosition;//mix(uMousePosition, vec2(0.5), smoothstep(0.3, 0.5, abs(length(0.5-uTransition))));
    
    // Dot Transition
    float dots = -0.1;
    vec2 dotUV = scaleUV(squareUV, vec2(1.0 + uTransition * 1.0), mousePos);
    vec2 uvMod = mix(applyCRTEffect(squareUV, .1, -.1), dotUV, uTransition) * zoom;
    float dotx = 0.;
    float iTime = mix(sin(time * uTimeStrength), uTransition * uTimeStrength, uTimeWithTransition);
    float size = uSize;
    size = uSize * crange(uTransition, 0., 1., 0., 2.0);
    dotx = circleExp(mousePos, crange(uTransition, 0.,1., 0., 15.));
    float sizeDotX =size * dotx;
    float bb1 = uBlur0 * uBlur;
    float bb2 = uBlur1 * uBlur;
    float bb3 = uBlur2 * uBlur;
    float size1 = uSize0 *sizeDotX;
    float size2 = uSize1 *sizeDotX;
    float size3 = uSize2 *sizeDotX;

    for(float i = 0.0; i < 3.; i++) {
        vec2 PLEASE_TAKE_CARE_OF_REPETITIONS = uvMod + vec2(i, 0.);
        dots += createDot(PLEASE_TAKE_CARE_OF_REPETITIONS, vec2(0., i), size1, bb1);
        dots += createDot(PLEASE_TAKE_CARE_OF_REPETITIONS, vec2(1., i), size2, bb2);
        dots += createDot(PLEASE_TAKE_CARE_OF_REPETITIONS, vec2(2. , i), size3, bb3);
    }
    
    // gl_FragColor = vec4(uColor, 1.0);
    gl_FragColor = vec4(uColor, mix(0.0, 1.0, 1.0- step(0.5, dots + dotx * 0.5)));
}