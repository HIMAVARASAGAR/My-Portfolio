precision highp float;
#!ATTRIBUTES

#!UNIFORMS
uniform sampler2D tMap;
uniform vec2 uResolution;
uniform vec2 uMapResolution;
uniform vec2 uBorder; // r: thickness g: radius
uniform vec3 uColor;
uniform vec3 uColor2;
uniform vec3 uBorderColor;
uniform float uAlpha; 
uniform float uBorderAlpha; 
uniform vec3 uAlphaValues; // r: AlphaBg g:ImageAlpha 
uniform sampler2D tDraw;
uniform float uType;
uniform float uTransition;
uniform float uActive;
uniform float uVelocity;

#!VARYINGS
varying vec2 vUv;
varying vec3 vPos;

#!SHADER: Vertex

void main() {
  vec3 pos = position;

  gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
  vUv = uv;
  vPos = pos;
}

#!SHADER: Fragment
#require(roundedBorder.glsl)
#require(rgb2hsv.fs)

void main() {
    float fluid = 0.;
    #test Tests.useFluids()
        vec3 drawer = texture2D(tDraw, gl_FragCoord.xy / resolution.xy).rgb;
        fluid = drawer.r + drawer.g;
        // fluid = drawer.r; // trail pointer
        // fluid = drawer.g; // fluid simulation
        // fluid = drawer.b; // pointer
    #endtest

    vec2 stR = uResolution.xy / uMapResolution;
    float m = max(stR.x, stR.y);
    vec2 uv = vUv - 0.5;
    uv *= stR;
    uv *= 1.0 / m;
    uv += 0.5;


    if(uType == 3.0) {
        
    }

    vec4 tex = texture2D(tMap, uv);
    vec3 color = vec3(uColor);

    #test Tests.useFluids()
        color = mix(uColor, uColor2, step(0.5, fluid * 2.0) );
    #endtest

    float inside = 1.0;
    float alpha = 1.0;
    if (uAlphaValues.g > 0.) {
            alpha = tex.a;
        }

    if (uBorder.x > 0.0 || uBorder.y > 0.0) {
        float border = roundedBorder(uBorder.x, uBorder.y, vUv, uResolution, inside);
        if(uType == 4.0) {
            vec2 innerUv = vUv;
            innerUv.y = innerUv.y;
            float tempBorder = border;
            border += max(step(innerUv.y, uTransition), border);
            border -= tempBorder;
        }

        vec3 borderColor = mix(uBorderColor, uColor, step(0.5, fluid * 2.));
        color = mix(color, borderColor, border * uBorderAlpha);

        if (uBorderAlpha < 1. && border == 1.0) {
            alpha = uBorderAlpha;
        } else {
            alpha = mix(border, inside, uAlphaValues.r);
            alpha = mix(alpha * uAlpha, tex.a * uAlpha, uAlphaValues.g);
        }

        #test Tests.useFluids()
            alpha += step(0.5, fluid * 2. * inside);
        #endtest
    } else {
        alpha = mix(uAlphaValues.r * uAlpha, tex.a * uAlpha, uAlphaValues.g);

        #test Tests.useFluids()
            alpha += step(0.5, fluid * 2.);
        #endtest
    }

    color = mix(color, tex.rgb, uAlphaValues.b);
    if (uType == 1.) {
        #test Tests.useFluids()
            color = mix(color, uBorderColor, step(0.5, fluid * 2.));

            // alpha = step(0.5, fluid * 2. * inside);
        #endtest
    }

    if(uType == 2.0 || uType == 3.0) {
        color = mix(uColor, uColor2, uActive);
        #test Tests.useFluids()
            color = mix(uColor, uColor2, step(0.5, fluid * 2.0) * tex.a);
        #endtest
        alpha = tex.a;
    }

    if (uTransition < .99) {
        // alpha *= uTransition;
    }

    if (uActive > 0.5) {
        color = uColor2;
        alpha = inside;
    }

    // vec2 peakUV = vUv;
    // vec3 rainbow = vec3(1.0, 0.15, 0.15);
    // rainbow = rgb2hsv(rainbow);
    // rainbow.x += sin(uVelocity * 0.02 + peakUV.y * 20.0);
    // rainbow = hsv2rgb(rainbow);
    // float peak = step(1.0-abs(uVelocity)*0.001, peakUV.y) + step(1.0-abs(uVelocity)*0.001, 1.0-peakUV.y);
    // color = mix(color, rainbow, peak);

    gl_FragColor = vec4(color, alpha);
}